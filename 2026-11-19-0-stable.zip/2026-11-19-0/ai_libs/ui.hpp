#pragma once
#include "../bilal_gui/gui.hpp"
#include "state.hpp"
#include "utils.hpp"
#include "storage.hpp"
#include "llm.hpp"
#include <algorithm>
#include <chrono>
#include <cstdio>

namespace ui {

inline int cancel_idx = -1;
inline int stats_idx  = -1;
inline std::string agent_info = "Agent: (none)";
inline std::chrono::steady_clock::time_point gen_start{};

inline gui::core::element& el(int idx) { return gui::core::ctx().elements[idx]; }
inline int last_idx() { return (int)gui::core::ctx().elements.size() - 1; }

inline void set_rect(int idx, int x, int y, int w, int h) {
    if (idx < 0) return;
    auto& e = el(idx);
    e.x = x; e.y = y; e.w = w; e.h = h;
}
inline void hide(int idx) { set_rect(idx, -10000, -10000, 200, 40); }

inline void set_box(int idx, const std::string& s, uint32_t fg, uint32_t bg, int cap_c, int cap_l) {
    if (idx < 0) return;
    std::string t = utils::cap_text(s, cap_c, cap_l);
    int lc = utils::line_count(t);
    auto& e = el(idx);
    e.edit_text   = t;
    e.maxchar     = std::max<int>(cap_c, (int)t.size() + 1024);
    e.maxlines    = std::max(cap_l, lc + 64);
    e.cursor_pos  = (int)t.size();
    e.scroll_line = (lc > 15) ? std::max(0, lc - 15) : 0;
    e.text_color  = fg;
    e.input_bg    = bg;
}

inline void set_ai(const std::string& s)   { set_box(g.ai_idx,   s, 0xFFFFFF, 0x000000, 200000, 4000); }
inline void set_user(const std::string& s) { set_box(g.user_idx, s, 0x000000, 0xFFFFFF, 100000, 2000); }

inline void update_stats(double avg_tps, double total_sec, int total_toks) {
    if (stats_idx < 0) return;
    char buf[512];
    std::snprintf(buf, sizeof(buf),
                  "%s\nAVG Tkns/s: %.2f\ntotal time: %.2fs\ntotal tokens: %d",
                  agent_info.c_str(), avg_tps, total_sec, total_toks);
    set_box(stats_idx, buf, 0xFFFFFF, 0x000000, 2000, 20);
    el(stats_idx).scroll_line = 0;
}

inline void show_error(const std::string& msg) {
    int slot = g.next_err++ % 4;
    int bi = g.err_box[slot], ci = g.err_close[slot];
    if (bi < 0) return;

    std::string t = utils::cap_text(msg, 4000, 200);
    auto& e = el(bi);
    e.edit_text = t;
    e.maxchar = std::max(1, (int)t.size());
    e.maxlines = std::max(1, utils::line_count(t));
    e.cursor_pos = e.scroll_line = 0;

    int W = gui::window_width(), H = gui::window_height();
    int w = W * 6 / 10, h = H * 3 / 10;
    int x = (W - w) / 2, y = (H - h) / 2 + slot * 20;
    set_rect(bi, x, y, w, h);
    set_rect(ci, x + w - 90, y - 32, 90, 28);
    el(ci).text_content = "close";
    el(ci).parent_menu  = -1;
    el(ci).visible      = true;
}

inline void refresh_menus() {
    for (int i = 0; i < g.chats_slots; ++i) {
        int fi = g.chats_scroll + i;
        el(g.chats_slot0 + i).text_content = (fi < (int)g.chat_files.size())
            ? storage::first_prompt_label(g.chat_dir + "/" + g.chat_files[fi]) : "";
    }

    std::vector<std::string> prompts;
    for (auto& m : g.history) if (m.role == "user") prompts.push_back(m.content);
    g.prompts_scroll = std::min(g.prompts_scroll, std::max(0, (int)prompts.size() - 1));

    for (int i = 0; i < g.prompts_slots; ++i) {
        int pi = g.prompts_scroll + i;
        if (pi < (int)prompts.size()) {
            std::string lbl = prompts[pi];
            std::replace(lbl.begin(), lbl.end(), '\n', ' ');
            el(g.prompts_slot0 + i).text_content = lbl.size() > 50 ? lbl.substr(0, 50) + "..." : lbl;
        } else {
            el(g.prompts_slot0 + i).text_content = "";
        }
    }
}

inline void layout() {
    int W = gui::window_width(), H = gui::window_height();
    if (W <= 0 || H <= 0) return;

    const int gap = 6, top_h = std::max(40, H / 14), bot_h = std::max(120, H / 7), item_h = std::max(32, top_h - gap);
    int chats_w = std::max(120, W / 9), prompts_w = std::max(160, W / 7);
    int right_x = gap + chats_w + gap + prompts_w + gap;
    int right_w = std::max(200, W - right_x - gap);
    int conv_y  = top_h + gap;
    int conv_h  = std::max(80, H - top_h - bot_h - 2 * gap);
    int ai_w    = (right_w - gap) * 55 / 100;

    set_rect(g.bg_idx, 0, 0, W, H);
    int bw = (W - 7 * gap) / 6;
    for (int i = 0; i < 6; ++i) set_rect(g.top_btn[i], gap + i * (bw + gap), gap / 2, bw, top_h - gap);

    auto place_menu = [&](int tog, int up, int dn, int slot0, int count, int x, int w) {
        int sb = std::max(20, item_h / 2), tw = std::max(40, w - 2 * gap - 2 * (sb + 3));
        set_rect(tog, x, conv_y, tw, item_h);
        set_rect(up,  x + tw + 3, conv_y, sb, item_h);
        set_rect(dn,  x + tw + sb + 6, conv_y, sb, item_h);
        int ly = conv_y + item_h + 2;
        int vis = std::max(0, (H - bot_h - gap - ly + 2) / (item_h + 2));
        for (int i = 0; i < count; ++i)
            (i < vis) ? set_rect(slot0 + i, x, ly + i * (item_h + 2), w - 2 * gap, item_h) : hide(slot0 + i);
    };
    place_menu(g.chats_menu,   g.chats_up,   g.chats_dn,   g.chats_slot0,   g.chats_slots,   gap, chats_w);
    place_menu(g.prompts_menu, g.prompts_up, g.prompts_dn, g.prompts_slot0, g.prompts_slots, gap + chats_w + gap, prompts_w);

    set_rect(g.ai_idx,   right_x, conv_y, ai_w, conv_h);
    set_rect(g.user_idx, right_x + ai_w + gap, conv_y, right_w - gap - ai_w, conv_h);

    int bot_y = H - bot_h + gap;
    int bot_inner_h = bot_h - 2 * gap;
    int send_w = std::max(100, W / 10);
    int in_w = std::max(160, (W - send_w - 4 * gap) / 2);
    int btn_x = gap + in_w + gap;
    int btn_h = (bot_inner_h - gap) / 2;
    int stats_x = btn_x + send_w + gap;
    int stats_w = std::max(160, W - stats_x - gap);

    set_rect(g.input_idx, gap, bot_y, in_w, bot_inner_h);
    set_rect(g.send_idx,  btn_x, bot_y, send_w, btn_h);
    set_rect(cancel_idx,  btn_x, bot_y + btn_h + gap, send_w, bot_inner_h - btn_h - gap);
    set_rect(stats_idx,   stats_x, bot_y, stats_w, bot_inner_h);

    // System prompt modal editor
    if (g.sys_editor_open) {
        int sw = W * 65 / 100, sh = H * 45 / 100;
        int sx = (W - sw) / 2, sy = (H - sh) / 2;
        set_rect(g.sys_box,       sx, sy, sw, sh);
        set_rect(g.sys_save_btn,  sx + sw - 130, sy - 34, 130, 30);
        set_rect(g.sys_reset_btn, sx + sw - 270, sy - 34, 130, 30);
    } else {
        hide(g.sys_box);
        hide(g.sys_save_btn);
        hide(g.sys_reset_btn);
    }

    int ew = W * 6 / 10, eh = H * 3 / 10;
    for (int s = 0; s < 4; ++s) {
        if (g.err_box[s] >= 0 && el(g.err_box[s]).x >= 0) {
            int x = (W - ew) / 2, y = (H - eh) / 2 + s * 20;
            set_rect(g.err_box[s], x, y, ew, eh);
            set_rect(g.err_close[s], x + ew - 90, y - 32, 90, 28);
        }
    }
}

inline void toggle_sys_editor(bool open) {
    g.sys_editor_open = open;
    if (open) {
        auto& e = el(g.sys_box);
        e.edit_text   = g.system_prompt;
        e.cursor_pos  = (int)g.system_prompt.size();
        e.scroll_line = 0;
    }
    layout();
}

inline void open_chat_slot(int slot) {
    if (slot < 0 || slot >= (int)g.chat_files.size()) return;
    std::string err;
    if (!storage::load_file(g.chat_dir + "/" + g.chat_files[slot], err)) { show_error(err); return; }

    std::string lu, la;
    for (auto& m : g.history) (m.role == "user" ? lu : la) = m.content;
    set_user(lu);
    set_ai(la);
    refresh_menus();
}

inline void jump_prompt(int p_idx) {
    int c = 0;
    for (size_t i = 0; i < g.history.size(); ++i) {
        if (g.history[i].role == "user" && c++ == p_idx) {
            set_user(g.history[i].content);
            set_ai((i + 1 < g.history.size() && g.history[i + 1].role == "assistant") ? g.history[i + 1].content : "");
            return;
        }
    }
}

inline void forget_chat() {
    if (g.generating) llm::finish();
    g.history.clear(); g.reply_buf.clear(); g.current_chat.clear();
    g.saved_count = 0; g.prompts_scroll = 0;
    set_ai(""); set_user("");
    el(g.input_idx).edit_text.clear(); el(g.input_idx).cursor_pos = 0;
    refresh_menus();
    if (g.model && !llm::make_context()) show_error("failed to reset context");
}

inline void send_message() {
    if (g.generating) return;
    if (!g.model || !g.ctx) { show_error("select a model first"); return; }
    auto& inp = el(g.input_idx);
    std::string text = inp.edit_text;
    while (!text.empty() && std::strchr("\n\r ", text.back())) text.pop_back();
    if (text.empty()) return;

    g.history.push_back({"user", text});
    set_user(text);
    inp.edit_text.clear();
    inp.cursor_pos = 0;
    refresh_menus();
    layout();

    std::string err;
    if (!llm::start(err)) show_error(err);
    else {
        gen_start = std::chrono::steady_clock::now();
        set_ai("...");
    }
}

inline void build_scene() {
    gui::background_color(1200, 800, 0, 0, gui::color::navy);
    g.bg_idx = last_idx();

    const char* labels[6] = {"chats dir", "select model", "save chat", "forget chat", "load chat", "system prompt"};
    for (int i = 0; i < 6; ++i) {
        gui::button_color_text(180, 40, 0, 0, gui::color::gray, labels[i], gui::color::white, [i]() {
            std::string err;
            if (i == 0) {
                if (auto d = utils::pick_dir(); !d.empty()) {
                    g.chat_dir = d; g.chats_scroll = 0; storage::scan_dir(); refresh_menus(); layout();
                }
            } else if (i == 1) {
                if (auto p = utils::pick_file("*.gguf"); !p.empty()) {
                    if (!llm::load_model(p, err)) show_error(err);
                    else {
                        std::string fname = std::filesystem::path(p).filename().string();
                        char desc[128] = {0};
                        llama_model_desc(g.model, desc, sizeof(desc));
                        double size_gb  = (double)llama_model_size(g.model) / (1024.0 * 1024.0 * 1024.0);
                        double params_b = (double)llama_model_n_params(g.model) / 1e9;
                        char info[256];
                        std::snprintf(info, sizeof(info), "Agent: %s\nInfo: %s | %.2fB | %.2fGB | ctx:%d",
                                      fname.c_str(), desc, params_b, size_gb, g.n_ctx);
                        agent_info = info;
                        update_stats(0.0, 0.0, 0);

                        refresh_menus();
                        set_ai("Model loaded.\nContext (GGUF): " + std::to_string(g.n_ctx) +
                               "\nMax reply: " + std::to_string(g.max_reply) +
                               "\nThreads: " + std::to_string(g.n_threads));
                    }
                }
            } else if (i == 2) {
                if (!storage::save_current(err)) { if (!err.empty()) show_error(err); }
                else { refresh_menus(); layout(); }
            } else if (i == 3) {
                forget_chat();
            } else if (i == 4) {
                if (auto p = utils::pick_file("*.txt"); !p.empty()) {
                    std::filesystem::path fp(p);
                    g.chat_dir = fp.parent_path().empty() ? "." : fp.parent_path().string();
                    storage::scan_dir(); refresh_menus(); layout();
                    auto it = std::find(g.chat_files.begin(), g.chat_files.end(), fp.filename().string());
                    if (it != g.chat_files.end()) open_chat_slot((int)std::distance(g.chat_files.begin(), it));
                    else show_error("file not found in " + g.chat_dir);
                }
            } else if (i == 5) {
                toggle_sys_editor(!g.sys_editor_open);
            }
        });
        g.top_btn[i] = last_idx();
    }

    auto build_menu = [](const char* title, uint32_t bg, bool vis, int& m_idx, int& u_idx, int& d_idx,
                         int& s0, int count, int& scroll, auto on_click) {
        auto m = gui::vmenu::create_text(140, 40, 0, 0, title, gui::color::white, bg);
        m_idx = last_idx();
        gui::core::ctx().menus[m.idx].visible = vis;
        gui::button_color_text(24, 40, 0, 0, gui::color::gray, "^", gui::color::white, [&]() {
            if (scroll > 0) { --scroll; refresh_menus(); layout(); }
        });
        u_idx = last_idx();
        gui::button_color_text(24, 40, 0, 0, gui::color::gray, "v", gui::color::white, [&]() {
            ++scroll; refresh_menus(); layout();
        });
        d_idx = last_idx();
        for (int s = 0; s < count; ++s) {
            gui::vmenu::button_color_text(m, 140, 30, 0, 0, gui::color::navy, "", gui::color::white, [s, on_click]() { on_click(s); });
            if (s == 0) s0 = last_idx();
            hide(last_idx());
        }
    };

    build_menu("chats", gui::color::teal, false, g.chats_menu, g.chats_up, g.chats_dn,
               g.chats_slot0, g.chats_slots, g.chats_scroll, [](int s) { open_chat_slot(g.chats_scroll + s); });

    build_menu("prompts", gui::color::gray, true, g.prompts_menu, g.prompts_up, g.prompts_dn,
               g.prompts_slot0, g.prompts_slots, g.prompts_scroll, [](int s) { jump_prompt(g.prompts_scroll + s); });

    gui::textbox(100, 100, 0, 0, "", "", 200000, 4000, 14, gui::color::white, gui::color::black);
    g.ai_idx = last_idx();
    gui::textbox(100, 100, 0, 0, "", "", 100000, 2000, 14, gui::color::black, gui::color::white);
    g.user_idx = last_idx();
    gui::textbox(100, 100, 0, 0, "", "", 100000, 2000, 14, gui::color::black, gui::color::white);
    g.input_idx = last_idx();

    gui::button_color_text(120, 40, 0, 0, gui::color::green, "send", gui::color::white, []() { send_message(); });
    g.send_idx = last_idx();

    gui::button_color_text(120, 40, 0, 0, gui::color::red, "cancel", gui::color::white, []() { forget_chat(); });
    cancel_idx = last_idx();

    gui::textbox(100, 100, 0, 0, "", "", 2000, 20, 12, gui::color::white, gui::color::black);
    stats_idx = last_idx();
    update_stats(0.0, 0.0, 0);

    // System prompt overlay widgets
    gui::textbox(100, 100, 0, 0, "", "", 16000, 400, 14, gui::color::black, gui::color::white);
    g.sys_box = last_idx(); hide(g.sys_box);

    gui::button_color_text(130, 30, 0, 0, gui::color::green, "save & close", gui::color::white, []() {
        g.system_prompt = el(g.sys_box).edit_text;
        toggle_sys_editor(false);
    });
    g.sys_save_btn = last_idx(); hide(g.sys_save_btn);

    gui::button_color_text(130, 30, 0, 0, gui::color::teal, "reset default", gui::color::white, []() {
        g.system_prompt = app_state::default_sys_prompt;
        el(g.sys_box).edit_text  = g.system_prompt;
        el(g.sys_box).cursor_pos = (int)g.system_prompt.size();
    });
    g.sys_reset_btn = last_idx(); hide(g.sys_reset_btn);

    for (int s = 0; s < 4; ++s) {
        gui::textbox(100, 100, 0, 0, "", "", 4000, 200, 12, gui::color::black, gui::color::pink);
        g.err_box[s] = last_idx(); hide(last_idx());
        gui::button_color_text(90, 28, 0, 0, gui::color::red, "close", gui::color::white, [s]() {
            hide(g.err_box[s]); hide(g.err_close[s]);
        });
        g.err_close[s] = last_idx(); hide(last_idx());
    }
}

inline void tick_and_draw() {
    auto& c = gui::core::ctx();
    int xfd = ConnectionNumber(c.dpy);

    auto render_now = [&]() {
        gui::render::draw_scene(c.backbuf);
        XCopyArea(c.dpy, c.backbuf, c.win, c.gc, 0, 0, c.width, c.height, 0, 0);
        XFlush(c.dpy);
    };

    render_now();
    while (c.running) {
        timeval tv{0, 10000};
        fd_set fds; FD_ZERO(&fds); FD_SET(xfd, &fds);
        if (select(xfd + 1, &fds, nullptr, nullptr, g.generating ? &tv : nullptr) < 0) {
            if (errno == EINTR) continue;
            break;
        }

        bool dirty = false;
        while (XPending(c.dpy)) {
            XEvent ev; XNextEvent(c.dpy, &ev);
            if (gui::render::process_event(ev)) dirty = true;
        }

        if (int w = gui::window_width(), h = gui::window_height(); w != g.last_w || h != g.last_h) {
            g.last_w = w; g.last_h = h; layout(); dirty = true;
        }

        bool finished = false;
        std::string err;
        if (llm::step(finished, err)) {
            if (!err.empty()) show_error(err);
            set_ai(g.reply_buf.empty() && finished ? "(empty response)" : g.reply_buf);
            if (finished) {
                double secs = std::chrono::duration<double>(std::chrono::steady_clock::now() - gen_start).count();
                double tps  = (secs > 0.0) ? ((double)g.reply_tokens / secs) : 0.0;
                update_stats(tps, secs, g.reply_tokens);
                refresh_menus();
            }
            dirty = true;
        }

        if (dirty && c.running) render_now();
    }
}

inline void shutdown() {
    if (g.generating) llm::finish();
    llm::free_model();
    llama_backend_free();
    auto& c = gui::core::ctx();
    for (auto& kv : c.image_cache) if (kv.second) XDestroyImage(kv.second);
    for (auto& kv : c.font_cache)  if (kv.second) XFreeFont(c.dpy, kv.second);
    if (c.backbuf) XFreePixmap(c.dpy, c.backbuf);
    if (c.gc)      XFreeGC(c.dpy, c.gc);
    if (c.win)     XDestroyWindow(c.dpy, c.win);
    if (c.dpy)     XCloseDisplay(c.dpy);
}

} // namespace ui