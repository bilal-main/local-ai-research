#pragma once
#include "state.hpp"
#include "utils.hpp"
#include "llama.h"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <climits>
#include <clocale>
#include <cstdio>
#include <string>
#include <thread>
#include <vector>

namespace llm {

// File-local runtime state (keeps state.hpp unchanged)
inline llama_batch_ext*      batch_ext = nullptr;
inline std::vector<chat_msg> synced_history;
inline std::string           synced_system;
inline std::string           synced_prefix;
inline std::string           active_system;

// ---------------------------------------------------------------------------
// One-time backend initialization
// ---------------------------------------------------------------------------
inline void ensure_backend_init() {
    static bool initialized = false;
    if (initialized) return;

    std::setlocale(LC_NUMERIC, "C");
    llama_log_set([](enum ggml_log_level level, const char* text, void*) {
        if (level >= GGML_LOG_LEVEL_ERROR && text) {
            std::fprintf(stderr, "%s", text);
        }
    }, nullptr);

    llama_backend_init();
    initialized = true;
}

// ---------------------------------------------------------------------------
// Text & UTF-8 helpers
// ---------------------------------------------------------------------------
inline void rstrip(std::string& s) {
    while (!s.empty() && std::isspace((unsigned char)s.back())) s.pop_back();
}

inline void trim_utf8_tail(std::string& s) {
    if (s.empty()) return;
    size_t k = s.size();
    while (k > 0 && ((unsigned char)s[k - 1] & 0xC0) == 0x80) --k;
    if (k == 0) { s.clear(); return; }
    unsigned char lead = (unsigned char)s[k - 1];
    size_t need = (lead >= 0xF0) ? 4 : (lead >= 0xE0) ? 3 : (lead >= 0xC0) ? 2 : 1;
    if (s.size() - (k - 1) < need) s.resize(k - 1);
}

// ---------------------------------------------------------------------------
// Tokenization & detokenization (bounds-checked)
// ---------------------------------------------------------------------------
inline std::vector<llama_token> tokenize(const std::string& s, bool add_special) {
    if (!g.vocab || s.empty() || s.size() > (size_t)INT_MAX) return {};

    const int need = -llama_tokenize(
        g.vocab, s.c_str(), (int)s.size(), nullptr, 0, add_special, true);
    if (need <= 0) return {};

    std::vector<llama_token> toks((size_t)need);
    const int got = llama_tokenize(
        g.vocab, s.c_str(), (int)s.size(), toks.data(), need, add_special, true);
    if (got < 0) return {};

    toks.resize((size_t)got);
    return toks;
}

inline std::string token_to_piece(llama_token tok) {
    if (!g.vocab) return {};

    char buf[256];
    int n = llama_token_to_piece(g.vocab, tok, buf, (int)sizeof(buf), 0, false);
    if (n >= 0) return std::string(buf, (size_t)n);
    if (n < -65536) return {};

    std::string big((size_t)(-n), '\0');
    int m = llama_token_to_piece(g.vocab, tok, big.data(), (int)big.size(), 0, false);
    return (m >= 0) ? big.substr(0, (size_t)m) : std::string{};
}

// ---------------------------------------------------------------------------
// KV memory & lifecycle management
// ---------------------------------------------------------------------------
inline int kv_used() {
    if (!g.ctx) return 0;
    const llama_pos max_pos = llama_memory_seq_pos_max(llama_get_memory(g.ctx), 0);
    return (max_pos >= 0) ? (int)(max_pos + 1) : 0;
}

inline void reset_kv() {
    if (g.ctx) llama_memory_seq_rm(llama_get_memory(g.ctx), 0, -1, -1);
    synced_history.clear();
    synced_system.clear();
    synced_prefix.clear();
    g.n_past = 0;
}

inline void free_context() {
    if (g.smpl)    { llama_sampler_free(g.smpl);      g.smpl    = nullptr; }
    if (batch_ext) { llama_batch_ext_free(batch_ext); batch_ext = nullptr; }
    if (g.ctx)     { llama_free(g.ctx);               g.ctx     = nullptr; }
    if (g.batch.token || g.batch.embd) llama_batch_free(g.batch);
    g.batch  = {};
    g.vocab  = nullptr;
    g.n_past = 0;
    synced_history.clear();
    synced_system.clear();
    synced_prefix.clear();
}

inline bool make_context() {
    if (!g.model) return false;
    free_context();

    const int ctx_train = llama_model_n_ctx_train(g.model);
    const int model_ctx = (ctx_train > 0) ? ctx_train : 4096;
    g.n_ctx     = std::clamp(model_ctx, 512, 4096);
    g.n_batch   = std::min(512, g.n_ctx);
    g.max_reply = std::clamp(g.n_ctx / 2, 256, 2048);

    const int hw = (int)std::thread::hardware_concurrency();
    g.n_threads  = std::clamp(hw > 0 ? hw / 2 : 4, 1, 12);

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx           = (uint32_t)g.n_ctx;
    cp.n_batch         = (uint32_t)g.n_batch;
    cp.n_threads       = g.n_threads;
    cp.n_threads_batch = std::clamp(hw > 0 ? hw : 4, 1, 16);

    g.ctx = llama_init_from_model(g.model, cp);
    if (!g.ctx) return false;

    g.vocab = llama_model_get_vocab(g.model);
    if (!g.vocab) { free_context(); return false; }

    batch_ext = llama_batch_ext_init(g.ctx);
    if (!batch_ext) { free_context(); return false; }

    return true;
}

inline void free_model() {
    free_context();
    if (g.model) { llama_model_free(g.model); g.model = nullptr; }
    g.history.clear();
    g.reply_buf.clear();
    g.current_chat.clear();
    g.saved_count    = 0;
    g.prompts_scroll = 0;
}

inline bool load_model(const std::string& path, std::string& err) {
    if (path.empty()) { err = "empty model path"; return false; }
    ensure_backend_init();

    if (g.model) free_model();

    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;

    g.model = llama_model_load_from_file(path.c_str(), mp);
    if (!g.model) { err = "failed to load model: " + path; return false; }

    if (!make_context()) {
        err = "failed to create context: " + path;
        free_model();
        return false;
    }
    return true;
}

// ---------------------------------------------------------------------------
// Chat template formatting
// ---------------------------------------------------------------------------
inline bool apply_template(const char* tmpl,
                           const std::vector<chat_msg>& list,
                           bool add_ass,
                           std::string& out) {
    if (list.empty()) return false;

    std::vector<llama_chat_message> cm;
    cm.reserve(list.size());
    for (const auto& m : list) cm.push_back({m.role.c_str(), m.content.c_str()});

    const int need = llama_chat_apply_template(tmpl, cm.data(), cm.size(), add_ass, nullptr, 0);
    if (need <= 0) return false;

    std::string buf((size_t)need + 1, '\0');
    const int wrote = llama_chat_apply_template(
        tmpl, cm.data(), cm.size(), add_ass, buf.data(), (int)buf.size());
    if (wrote <= 0 || wrote > (int)buf.size()) return false;

    buf.resize((size_t)wrote);
    out = std::move(buf);
    return true;
}

inline std::vector<chat_msg> compose_messages(const std::string& sys,
                                              const std::vector<chat_msg>& hist) {
    std::vector<chat_msg> msgs;
    msgs.reserve(hist.size() + 1);
    if (!sys.empty()) msgs.push_back({"system", sys});
    msgs.insert(msgs.end(), hist.begin(), hist.end());
    return msgs;
}

inline std::string format_messages(const std::vector<chat_msg>& msgs, bool add_ass) {
    const char* tmpl = llama_model_chat_template(g.model, nullptr);
    std::string out;

    if (apply_template(tmpl, msgs, add_ass, out)) return out;

    // Fallback for templates (e.g. Gemma) that reject the "system" role
    if (msgs.size() >= 2 && msgs.front().role == "system") {
        std::vector<chat_msg> folded(msgs.begin() + 1, msgs.end());
        folded.front().content = msgs.front().content + "\n\n" + folded.front().content;
        if (apply_template(tmpl, folded, add_ass, out)) return out;
    }

    for (const auto& m : msgs) {
        if (m.role == "system")    out += "System: " + m.content + "\n\n";
        else if (m.role == "user") out += "User: " + m.content + "\n";
        else                       out += "Assistant: " + m.content + "\n";
    }
    if (add_ass) out += "Assistant:";
    return out;
}

// ---------------------------------------------------------------------------
// Sampler & batch decoding (matching simple-chat.cpp)
// ---------------------------------------------------------------------------
inline bool build_sampler() {
    if (g.smpl) { llama_sampler_free(g.smpl); g.smpl = nullptr; }

    g.smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (!g.smpl) return false;

    llama_sampler_chain_add(g.smpl, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(g.smpl, llama_sampler_init_top_p(0.95f, 1));
    llama_sampler_chain_add(g.smpl, llama_sampler_init_min_p(0.05f, 1));
    llama_sampler_chain_add(g.smpl, llama_sampler_init_temp(0.8f));
    llama_sampler_chain_add(g.smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    return true;
}

inline bool decode_chunk(const llama_token* toks, int32_t n_tokens, bool want_logits) {
    if (!g.ctx || !batch_ext || !toks || n_tokens <= 0 || n_tokens > g.n_batch) return false;

    const int32_t n_ctx = (int32_t)llama_n_ctx(g.ctx);
    const llama_pos pos_0 = (llama_pos)kv_used();
    if (pos_0 + n_tokens > n_ctx) return false;

    llama_batch_ext_clear(batch_ext);
    int32_t last_idx = -1;
    for (int32_t i = 0; i < n_tokens; ++i) {
        last_idx = llama_batch_ext_add_token(batch_ext, 0, toks[i]);
        if (last_idx < 0) return false;
        const llama_pos pos = pos_0 + i;
        llama_batch_ext_set_pos(batch_ext, last_idx, &pos);
    }
    if (want_logits && last_idx >= 0) {
        llama_batch_ext_set_output_logits(batch_ext, last_idx, true);
    }

    if (llama_process(g.ctx, LLAMA_PROCESS_TYPE_DECODE, batch_ext) != 0) return false;
    g.n_past = kv_used();
    return true;
}

inline bool decode_tokens(const std::vector<llama_token>& toks) {
    if (toks.empty()) return false;
    for (size_t off = 0; off < toks.size(); off += (size_t)g.n_batch) {
        const int32_t n = (int32_t)std::min((size_t)g.n_batch, toks.size() - off);
        const bool is_last = (off + (size_t)n == toks.size());
        if (!decode_chunk(toks.data() + off, n, is_last)) return false;
    }
    return true;
}

inline bool history_extends_synced(const std::string& sys) {
    if (synced_prefix.empty() || kv_used() == 0) return false;
    if (sys != synced_system) return false;
    if (g.history.size() != synced_history.size() + 1) return false;

    for (size_t i = 0; i < synced_history.size(); ++i) {
        if (g.history[i].role != synced_history[i].role ||
            g.history[i].content != synced_history[i].content) {
            return false;
        }
    }
    return true;
}

// ---------------------------------------------------------------------------
// Public generation API
// ---------------------------------------------------------------------------
inline void finish() {
    if (g.smpl) { llama_sampler_free(g.smpl); g.smpl = nullptr; }

    trim_utf8_tail(g.reply_buf);
    while (!g.reply_buf.empty() && (g.reply_buf.front() == '\n' || g.reply_buf.front() == '\r')) {
        g.reply_buf.erase(g.reply_buf.begin());
    }
    rstrip(g.reply_buf);

    if (!g.reply_buf.empty()) {
        if (g.history.empty() || g.history.back().role != "assistant")
            g.history.push_back({"assistant", g.reply_buf});
        else
            g.history.back().content = g.reply_buf;
    }

    if (g.ctx && g.model && kv_used() > 0 && !g.history.empty()) {
        synced_system  = active_system;
        synced_history = g.history;
        synced_prefix  = format_messages(compose_messages(synced_system, synced_history), false);
    } else {
        synced_history.clear();
        synced_system.clear();
        synced_prefix.clear();
    }

    g.generating = false;
}

inline bool start(std::string& err) {
    if (!g.model || !g.ctx || !g.vocab || !batch_ext) { err = "no model loaded"; return false; }
    if (g.history.empty() || g.history.back().role != "user") { err = "no user message"; return false; }

    std::string sys = g.system_prompt;
    rstrip(sys);
    active_system = sys;

    const int n_ctx   = (int)llama_n_ctx(g.ctx);
    const int reserve = std::min(g.max_reply, n_ctx / 2) + 8;
    const int budget  = std::max(64, n_ctx - reserve);

    std::vector<llama_token> to_decode;

    // Fast path: exact multi-turn continuation (same delta mechanism as simple-chat.cpp)
    if (history_extends_synced(sys)) {
        const std::string full = format_messages(compose_messages(sys, g.history), true);
        if (full.size() > synced_prefix.size() && full.compare(0, synced_prefix.size(), synced_prefix) == 0) {
            const std::string delta = full.substr(synced_prefix.size());
            auto delta_toks = tokenize(delta, false);
            if (!delta_toks.empty() && kv_used() + (int)delta_toks.size() <= budget) {
                to_decode = std::move(delta_toks);
            }
        }
    }

    // Full encode path: first turn, switched/edited chat, or context rollover
    if (to_decode.empty()) {
        reset_kv();
        std::vector<chat_msg> hist = g.history;
        const llama_token bos = llama_vocab_bos(g.vocab);

        for (;;) {
            const std::string prompt = format_messages(compose_messages(sys, hist), true);
            auto toks = tokenize(prompt, true);
            if (bos != LLAMA_TOKEN_NULL && toks.size() >= 2 && toks[0] == bos && toks[1] == bos) {
                toks.erase(toks.begin());
            }
            if (toks.empty()) { err = "tokenize failed"; return false; }

            if ((int)toks.size() <= budget) {
                to_decode = std::move(toks);
                break;
            }

            if (hist.size() <= 1) {
                toks.erase(toks.begin(), toks.end() - budget);
                if (bos != LLAMA_TOKEN_NULL) toks.front() = bos;
                to_decode = std::move(toks);
                break;
            }
            hist.erase(hist.begin());
            while (hist.size() > 1 && hist.front().role != "user") hist.erase(hist.begin());
        }
    }

    if (!decode_tokens(to_decode)) {
        reset_kv();
        err = "decode failed on prompt";
        return false;
    }

    if (!build_sampler()) {
        err = "failed to initialize sampler";
        return false;
    }

    g.reply_buf.clear();
    g.reply_tokens = 0;
    g.last_flush   = utils::now_ms();
    g.generating   = true;
    return true;
}

inline bool step(bool& finished, std::string& err) {
    finished = false;
    if (!g.generating || !g.ctx || !g.vocab || !g.smpl || !batch_ext) return false;

    const int n_ctx = (int)llama_n_ctx(g.ctx);
    const auto t0   = utils::clk::now();

    while (g.generating && utils::clk::now() - t0 < std::chrono::milliseconds(40)) {
        const llama_token tok = llama_sampler_sample(g.smpl, g.ctx, -1);

        if (llama_vocab_is_eog(g.vocab, tok)) {
            finish();
            finished = true;
            return true;
        }

        g.reply_buf += token_to_piece(tok);
        ++g.reply_tokens;

        if (g.reply_tokens >= g.max_reply || kv_used() >= n_ctx - 1) {
            finish();
            finished = true;
            return true;
        }

        if (!decode_chunk(&tok, 1, true)) {
            err = "decode failed while generating";
            reset_kv();
            finish();
            finished = true;
            return true;
        }
    }

    if (g.generating && utils::now_ms() - g.last_flush >= 150) {
        g.last_flush = utils::now_ms();
        return true;
    }
    return false;
}

} // namespace llm