#include "ai_libs/ui.hpp"

int main() {
    if (!gui::init(1200, 800, "local chat")) return 1;
    llama_backend_init();

    ui::build_scene();
    storage::scan_dir();
    ui::refresh_menus();
    ui::layout();
    g.last_w = gui::window_width();
    g.last_h = gui::window_height();

    ui::tick_and_draw();
    ui::shutdown();
    return 0;
}