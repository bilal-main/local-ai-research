keep the structure of
main.cpp
llamacpp //the statically linked llamacpp full package in this build it's linked for linux
buildAI.sh //must be in the same directory, use chmod +x buildAI.sh if normal use failed then run ./buildAI again
    ai_libs
        .hpp//several .hpp files
    bilal_gui
        .hpp//several .hpp files
