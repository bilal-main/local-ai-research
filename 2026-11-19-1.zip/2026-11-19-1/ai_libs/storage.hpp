#pragma once
#include "state.hpp"
#include "utils.hpp"
#include <cstdio>
#include <filesystem>
#include <algorithm>

namespace storage {

inline std::vector<chat_msg> parse_chat(const std::string& data) {
    std::vector<chat_msg> out;
    bool use_markers = data.find("//00P") != std::string::npos;

    if (use_markers) {
        std::string role, content;
        auto flush = [&]() {
            while (!content.empty() && (content.back() == '\n' || content.back() == '\r'))
                content.pop_back();
            if (!role.empty()) out.push_back({role, content});
            content.clear();
        };
        for (size_t i = 0; i < data.size(); ) {
            if (data.compare(i, 5, "//00P") == 0) {
                flush(); role = "user"; i += 5 + (i + 5 < data.size() && data[i + 5] == '\n');
            } else if (data.compare(i, 5, "//00R") == 0) {
                flush(); role = "assistant"; i += 5 + (i + 5 < data.size() && data[i + 5] == '\n');
            } else {
                content += data[i++];
            }
        }
        flush();
    } else {
        for (size_t i = 0; i < data.size(); ) {
            size_t nl = data.find('\n', i);
            if (nl == std::string::npos) nl = data.size();
            std::string line = data.substr(i, nl - i);
            if (line.rfind("USER: ", 0) == 0)           out.push_back({"user", line.substr(6)});
            else if (line.rfind("ASSISTANT: ", 0) == 0) out.push_back({"assistant", line.substr(11)});
            else if (!out.empty() && !line.empty())     out.back().content += "\n" + line;
            i = nl + 1;
        }
    }
    return out;
}

inline std::string first_prompt_label(const std::string& path) {
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) return {};
    char buf[4096];
    size_t n = fread(buf, 1, sizeof(buf), f);
    fclose(f);

    for (auto& m : parse_chat(std::string(buf, n))) {
        if (m.role == "user") {
            std::string s = m.content;
            while (!s.empty() && std::strchr("\n\r ", s.front())) s.erase(s.begin());
            if (auto nl = s.find('\n'); nl != std::string::npos) s.resize(nl);
            return s.size() > 40 ? s.substr(0, 40) + "..." : s;
        }
    }
    return std::filesystem::path(path).stem().string();
}

inline void scan_dir() {
    g.chat_files.clear();
    std::error_code ec;
    std::filesystem::create_directories(g.chat_dir, ec);
    for (auto& p : std::filesystem::directory_iterator(g.chat_dir, ec)) {
        if (!ec && p.is_regular_file(ec)) {
            auto ext = p.path().extension().string();
            if (ext == ".txt" || ext == ".TXT")
                g.chat_files.push_back(p.path().filename().string());
        }
    }
    std::sort(g.chat_files.begin(), g.chat_files.end());
    g.chats_scroll = std::min(g.chats_scroll, std::max(0, (int)g.chat_files.size() - 1));
}

inline bool load_file(const std::string& path, std::string& err) {
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) { err = "cannot open " + path; return false; }
    std::string data;
    char buf[4096];
    for (size_t n; (n = fread(buf, 1, sizeof(buf), f)) > 0; ) {
        data.append(buf, n);
        if (data.size() > 8u * 1024u * 1024u) { fclose(f); err = "file too large"; return false; }
    }
    fclose(f);

    auto parsed = parse_chat(data);
    if (parsed.empty()) { err = "no messages in " + path; return false; }

    g.history        = std::move(parsed);
    g.current_chat   = path;
    g.saved_count    = g.history.size();
    g.prompts_scroll = 0;
    return true;
}

inline bool save_current(std::string& err) {
    if (g.generating && !g.reply_buf.empty()) {
        if (g.history.empty() || g.history.back().role != "assistant")
            g.history.push_back({"assistant", g.reply_buf});
        else
            g.history.back().content = g.reply_buf;
    }
    if (g.history.empty()) { err = "nothing to save"; return false; }

    bool first_save = g.current_chat.empty();
    if (first_save) {
        std::string dir = utils::pick_dir();
        if (dir.empty()) return false;
        g.chat_dir = dir;

        std::string first_prompt;
        for (auto& m : g.history) if (m.role == "user") { first_prompt = m.content; break; }
        std::string base = g.chat_dir + "/" + utils::sanitize_filename(first_prompt);
        std::string path = base + ".txt";
        for (int i = 1; std::filesystem::exists(path) && i < 1000; ++i)
            path = base + "_" + std::to_string(i) + ".txt";

        g.current_chat = path;
        g.saved_count  = 0;
    }

    FILE* f = fopen(g.current_chat.c_str(), first_save ? "wb" : "ab");
    if (!f) { err = "cannot write " + g.current_chat; return false; }

    for (size_t i = g.saved_count; i < g.history.size(); ++i) {
        const char* tag = (g.history[i].role == "user") ? "//00P\n" : "//00R\n";
        if (fputs(tag, f) < 0 ||
            fwrite(g.history[i].content.data(), 1, g.history[i].content.size(), f) != g.history[i].content.size() ||
            fputc('\n', f) == EOF) {
            fclose(f);
            err = "write failed";
            return false;
        }
    }
    fflush(f);
    fclose(f);
    g.saved_count = g.history.size();
    scan_dir();
    return true;
}

} // namespace storage