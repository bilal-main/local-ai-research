#pragma once
#include "llm_core.hpp"
#include <chrono>

namespace llm {

// ---------------------------------------------------------------------------
// Chat template formatting
// ---------------------------------------------------------------------------
inline bool apply_template(const char* tmpl,
                           const std::vector<chat_msg>& list,
                           bool add_ass,
                           std::string& out) {
    if (list.empty()) return false;

    std::vector<llama_chat_message> cm;
    cm.reserve(list.size());
    for (const auto& m : list) cm.push_back({m.role.c_str(), m.content.c_str()});

    const int need = llama_chat_apply_template(tmpl, cm.data(), cm.size(), add_ass, nullptr, 0);
    if (need <= 0) return false;

    std::string buf((size_t)need + 1, '\0');
    const int wrote = llama_chat_apply_template(
        tmpl, cm.data(), cm.size(), add_ass, buf.data(), (int)buf.size());
    if (wrote <= 0 || wrote > (int)buf.size()) return false;

    buf.resize((size_t)wrote);
    out = std::move(buf);
    return true;
}

inline std::vector<chat_msg> compose_messages(const std::string& sys,
                                              const std::vector<chat_msg>& hist) {
    std::vector<chat_msg> msgs;
    msgs.reserve(hist.size() + 1);
    if (!sys.empty()) msgs.push_back({"system", sys});
    msgs.insert(msgs.end(), hist.begin(), hist.end());
    return msgs;
}

inline std::string format_messages(const std::vector<chat_msg>& msgs, bool add_ass) {
    const char* tmpl = llama_model_chat_template(g.model, nullptr);
    std::string out;

    if (apply_template(tmpl, msgs, add_ass, out)) return out;

    // Fallback for templates (e.g. Gemma) that reject the "system" role
    if (msgs.size() >= 2 && msgs.front().role == "system") {
        std::vector<chat_msg> folded(msgs.begin() + 1, msgs.end());
        folded.front().content = msgs.front().content + "\n\n" + folded.front().content;
        if (apply_template(tmpl, folded, add_ass, out)) return out;
    }

    for (const auto& m : msgs) {
        if (m.role == "system")    out += "System: " + m.content + "\n\n";
        else if (m.role == "user") out += "User: " + m.content + "\n";
        else                       out += "Assistant: " + m.content + "\n";
    }
    if (add_ass) out += "Assistant:";
    return out;
}

// ---------------------------------------------------------------------------
// Sampler & batch decoding
// ---------------------------------------------------------------------------
inline bool build_sampler() {
    if (g.smpl) { llama_sampler_free(g.smpl); g.smpl = nullptr; }

    g.smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (!g.smpl) return false;

    llama_sampler_chain_add(g.smpl, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(g.smpl, llama_sampler_init_top_p(0.95f, 1));
    llama_sampler_chain_add(g.smpl, llama_sampler_init_min_p(0.05f, 1));
    llama_sampler_chain_add(g.smpl, llama_sampler_init_temp(0.8f));
    llama_sampler_chain_add(g.smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    return true;
}

inline bool decode_chunk(const llama_token* toks, int32_t n_tokens, bool want_logits) {
    if (!g.ctx || !batch_ext || !toks || n_tokens <= 0 || n_tokens > g.n_batch) return false;

    const int32_t n_ctx = (int32_t)llama_n_ctx(g.ctx);
    const llama_pos pos_0 = (llama_pos)kv_used();
    if (pos_0 + n_tokens > n_ctx) return false;

    llama_batch_ext_clear(batch_ext);
    int32_t last_idx = -1;
    for (int32_t i = 0; i < n_tokens; ++i) {
        last_idx = llama_batch_ext_add_token(batch_ext, 0, toks[i]);
        if (last_idx < 0) return false;
        const llama_pos pos = pos_0 + i;
        llama_batch_ext_set_pos(batch_ext, last_idx, &pos);
    }
    if (want_logits && last_idx >= 0) {
        llama_batch_ext_set_output_logits(batch_ext, last_idx, true);
    }

    if (llama_process(g.ctx, LLAMA_PROCESS_TYPE_DECODE, batch_ext) != 0) return false;
    g.n_past = kv_used();
    return true;
}

inline bool decode_tokens(const std::vector<llama_token>& toks) {
    if (toks.empty()) return false;
    for (size_t off = 0; off < toks.size(); off += (size_t)g.n_batch) {
        const int32_t n = (int32_t)std::min((size_t)g.n_batch, toks.size() - off);
        const bool is_last = (off + (size_t)n == toks.size());
        if (!decode_chunk(toks.data() + off, n, is_last)) return false;
    }
    return true;
}

inline bool history_extends_synced(const std::string& sys) {
    if (synced_prefix.empty() || kv_used() == 0) return false;
    if (sys != synced_system) return false;
    if (g.history.size() != synced_history.size() + 1) return false;

    for (size_t i = 0; i < synced_history.size(); ++i) {
        if (g.history[i].role != synced_history[i].role ||
            g.history[i].content != synced_history[i].content) {
            return false;
        }
    }
    return true;
}

// ---------------------------------------------------------------------------
// Public generation API
// ---------------------------------------------------------------------------
inline void finish() {
    if (g.smpl) { llama_sampler_free(g.smpl); g.smpl = nullptr; }

    trim_utf8_tail(g.reply_buf);
    while (!g.reply_buf.empty() && (g.reply_buf.front() == '\n' || g.reply_buf.front() == '\r')) {
        g.reply_buf.erase(g.reply_buf.begin());
    }
    rstrip(g.reply_buf);

    if (!g.reply_buf.empty()) {
        if (g.history.empty() || g.history.back().role != "assistant")
            g.history.push_back({"assistant", g.reply_buf});
        else
            g.history.back().content = g.reply_buf;
    }

    if (g.ctx && g.model && kv_used() > 0 && !g.history.empty()) {
        synced_system  = active_system;
        synced_history = g.history;
        synced_prefix  = format_messages(compose_messages(synced_system, synced_history), false);
    } else {
        synced_history.clear();
        synced_system.clear();
        synced_prefix.clear();
    }

    g.generating = false;
}

inline bool start(std::string& err) {
    if (!g.model || !g.ctx || !g.vocab || !batch_ext) { err = "no model loaded"; return false; }
    if (g.history.empty() || g.history.back().role != "user") { err = "no user message"; return false; }

    std::string sys = g.system_prompt;
    rstrip(sys);
    active_system = sys;

    const int n_ctx   = (int)llama_n_ctx(g.ctx);
    const int reserve = std::min(g.max_reply, n_ctx / 2) + 8;
    const int budget  = std::max(64, n_ctx - reserve);

    std::vector<llama_token> to_decode;

    if (history_extends_synced(sys)) {
        const std::string full = format_messages(compose_messages(sys, g.history), true);
        if (full.size() > synced_prefix.size() && full.compare(0, synced_prefix.size(), synced_prefix) == 0) {
            const std::string delta = full.substr(synced_prefix.size());
            auto delta_toks = tokenize(delta, false);
            if (!delta_toks.empty() && kv_used() + (int)delta_toks.size() <= budget) {
                to_decode = std::move(delta_toks);
            }
        }
    }

    if (to_decode.empty()) {
        reset_kv();
        std::vector<chat_msg> hist = g.history;
        const llama_token bos = llama_vocab_bos(g.vocab);

        for (;;) {
            const std::string prompt = format_messages(compose_messages(sys, hist), true);
            auto toks = tokenize(prompt, true);
            if (bos != LLAMA_TOKEN_NULL && toks.size() >= 2 && toks[0] == bos && toks[1] == bos) {
                toks.erase(toks.begin());
            }
            if (toks.empty()) { err = "tokenize failed"; return false; }

            if ((int)toks.size() <= budget) {
                to_decode = std::move(toks);
                break;
            }

            if (hist.size() <= 1) {
                toks.erase(toks.begin(), toks.end() - budget);
                if (bos != LLAMA_TOKEN_NULL) toks.front() = bos;
                to_decode = std::move(toks);
                break;
            }
            hist.erase(hist.begin());
            while (hist.size() > 1 && hist.front().role != "user") hist.erase(hist.begin());
        }
    }

    if (!decode_tokens(to_decode)) {
        reset_kv();
        err = "decode failed on prompt";
        return false;
    }

    if (!build_sampler()) {
        err = "failed to initialize sampler";
        return false;
    }

    g.reply_buf.clear();
    g.reply_tokens = 0;
    g.last_flush   = utils::now_ms();
    g.generating   = true;
    return true;
}

inline bool step(bool& finished, std::string& err) {
    finished = false;
    if (!g.generating || !g.ctx || !g.vocab || !g.smpl || !batch_ext) return false;

    const int n_ctx = (int)llama_n_ctx(g.ctx);
    const auto t0   = utils::clk::now();

    while (g.generating && utils::clk::now() - t0 < std::chrono::milliseconds(40)) {
        const llama_token tok = llama_sampler_sample(g.smpl, g.ctx, -1);

        if (llama_vocab_is_eog(g.vocab, tok)) {
            finish();
            finished = true;
            return true;
        }

        g.reply_buf += token_to_piece(tok);
        ++g.reply_tokens;

        if (g.reply_tokens >= g.max_reply || kv_used() >= n_ctx - 1) {
            finish();
            finished = true;
            return true;
        }

        if (!decode_chunk(&tok, 1, true)) {
            err = "decode failed while generating";
            reset_kv();
            finish();
            finished = true;
            return true;
        }
    }

    if (g.generating && utils::now_ms() - g.last_flush >= 150) {
        g.last_flush = utils::now_ms();
        return true;
    }
    return false;
}

} // namespace llm