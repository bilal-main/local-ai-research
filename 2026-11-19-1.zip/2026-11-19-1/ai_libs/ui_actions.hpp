#pragma once
#include "ui_widgets.hpp"

namespace ui {

inline void toggle_sys_editor(bool open) {
    g.sys_editor_open = open;
    if (open) {
        auto& e = el(g.sys_box);
        e.edit_text   = g.system_prompt;
        e.cursor_pos  = (int)g.system_prompt.size();
        e.scroll_line = 0;
    }
    layout();
}

inline void open_chat_slot(int slot) {
    if (slot < 0 || slot >= (int)g.chat_files.size()) return;
    std::string err;
    if (!storage::load_file(g.chat_dir + "/" + g.chat_files[slot], err)) { show_error(err); return; }

    std::string lu, la;
    for (auto& m : g.history) (m.role == "user" ? lu : la) = m.content;
    set_user(lu);
    set_ai(la);
    refresh_menus();
}

inline void jump_prompt(int p_idx) {
    int c = 0;
    for (size_t i = 0; i < g.history.size(); ++i) {
        if (g.history[i].role == "user" && c++ == p_idx) {
            set_user(g.history[i].content);
            set_ai((i + 1 < g.history.size() && g.history[i + 1].role == "assistant") ? g.history[i + 1].content : "");
            return;
        }
    }
}

inline void forget_chat() {
    if (g.generating) llm::finish();
    g.history.clear(); g.reply_buf.clear(); g.current_chat.clear();
    g.saved_count = 0; g.prompts_scroll = 0;
    set_ai(""); set_user("");
    el(g.input_idx).edit_text.clear(); el(g.input_idx).cursor_pos = 0;
    refresh_menus();
    if (g.model && !llm::make_context()) show_error("failed to reset context");
}

inline void send_message() {
    if (g.generating) return;
    if (!g.model || !g.ctx) { show_error("select a model first"); return; }
    auto& inp = el(g.input_idx);
    std::string text = inp.edit_text;
    while (!text.empty() && std::strchr("\n\r ", text.back())) text.pop_back();
    if (text.empty()) return;

    g.history.push_back({"user", text});
    set_user(text);
    inp.edit_text.clear();
    inp.cursor_pos = 0;
    refresh_menus();
    layout();

    std::string err;
    if (!llm::start(err)) show_error(err);
    else {
        gen_start = std::chrono::steady_clock::now();
        set_ai("...");
    }
}

inline void build_scene() {
    gui::background_color(1200, 800, 0, 0, gui::color::navy);
    g.bg_idx = last_idx();

    const char* labels[6] = {"chats dir", "select model", "save chat", "forget chat", "load chat", "system prompt"};
    for (int i = 0; i < 6; ++i) {
        gui::button_color_text(180, 40, 0, 0, gui::color::gray, labels[i], gui::color::white, [i]() {
            std::string err;
            if (i == 0) {
                if (auto d = utils::pick_dir(); !d.empty()) {
                    g.chat_dir = d; g.chats_scroll = 0; storage::scan_dir(); refresh_menus(); layout();
                }
            } else if (i == 1) {
                if (auto p = utils::pick_file("*.gguf"); !p.empty()) {
                    if (!llm::load_model(p, err)) show_error(err);
                    else {
                        std::string fname = std::filesystem::path(p).filename().string();
                        char desc[128] = {0};
                        llama_model_desc(g.model, desc, sizeof(desc));
                        double size_gb  = (double)llama_model_size(g.model) / (1024.0 * 1024.0 * 1024.0);
                        double params_b = (double)llama_model_n_params(g.model) / 1e9;
                        char info[256];
                        std::snprintf(info, sizeof(info), "Agent: %s\nInfo: %s | %.2fB | %.2fGB | ctx:%d",
                                      fname.c_str(), desc, params_b, size_gb, g.n_ctx);
                        agent_info = info;
                        update_stats(0.0, 0.0, 0);

                        refresh_menus();
                        set_ai("Model loaded.\nContext (GGUF): " + std::to_string(g.n_ctx) +
                               "\nMax reply: " + std::to_string(g.max_reply) +
                               "\nThreads: " + std::to_string(g.n_threads));
                    }
                }
            } else if (i == 2) {
                if (!storage::save_current(err)) { if (!err.empty()) show_error(err); }
                else { refresh_menus(); layout(); }
            } else if (i == 3) {
                forget_chat();
            } else if (i == 4) {
                if (auto p = utils::pick_file("*.txt"); !p.empty()) {
                    std::filesystem::path fp(p);
                    g.chat_dir = fp.parent_path().empty() ? "." : fp.parent_path().string();
                    storage::scan_dir(); refresh_menus(); layout();
                    auto it = std::find(g.chat_files.begin(), g.chat_files.end(), fp.filename().string());
                    if (it != g.chat_files.end()) open_chat_slot((int)std::distance(g.chat_files.begin(), it));
                    else show_error("file not found in " + g.chat_dir);
                }
            } else if (i == 5) {
                toggle_sys_editor(!g.sys_editor_open);
            }
        });
        g.top_btn[i] = last_idx();
    }

    auto build_menu = [](const char* title, uint32_t bg, bool vis, int& m_idx, int& u_idx, int& d_idx,
                         int& s0, int count, int& scroll, auto on_click) {
        auto m = gui::vmenu::create_text(140, 40, 0, 0, title, gui::color::white, bg);
        m_idx = last_idx();
        gui::core::ctx().menus[m.idx].visible = vis;
        gui::button_color_text(24, 40, 0, 0, gui::color::gray, "^", gui::color::white, [&]() {
            if (scroll > 0) { --scroll; refresh_menus(); layout(); }
        });
        u_idx = last_idx();
        gui::button_color_text(24, 40, 0, 0, gui::color::gray, "v", gui::color::white, [&]() {
            ++scroll; refresh_menus(); layout();
        });
        d_idx = last_idx();
        for (int s = 0; s < count; ++s) {
            gui::vmenu::button_color_text(m, 140, 30, 0, 0, gui::color::navy, "", gui::color::white, [s, on_click]() { on_click(s); });
            if (s == 0) s0 = last_idx();
            hide(last_idx());
        }
    };

    build_menu("chats", gui::color::teal, false, g.chats_menu, g.chats_up, g.chats_dn,
               g.chats_slot0, g.chats_slots, g.chats_scroll, [](int s) { open_chat_slot(g.chats_scroll + s); });

    build_menu("prompts", gui::color::gray, true, g.prompts_menu, g.prompts_up, g.prompts_dn,
               g.prompts_slot0, g.prompts_slots, g.prompts_scroll, [](int s) { jump_prompt(g.prompts_scroll + s); });

    gui::textbox(100, 100, 0, 0, "", "", 200000, 4000, 14, gui::color::white, gui::color::black);
    g.ai_idx = last_idx();
    gui::textbox(100, 100, 0, 0, "", "", 100000, 2000, 14, gui::color::black, gui::color::white);
    g.user_idx = last_idx();
    gui::textbox(100, 100, 0, 0, "", "", 100000, 2000, 14, gui::color::black, gui::color::white);
    g.input_idx = last_idx();

    gui::button_color_text(120, 40, 0, 0, gui::color::green, "send", gui::color::white, []() { send_message(); });
    g.send_idx = last_idx();

    gui::button_color_text(120, 40, 0, 0, gui::color::red, "cancel", gui::color::white, []() { forget_chat(); });
    cancel_idx = last_idx();

    gui::textbox(100, 100, 0, 0, "", "", 2000, 20, 12, gui::color::white, gui::color::black);
    stats_idx = last_idx();
    update_stats(0.0, 0.0, 0);

    gui::textbox(100, 100, 0, 0, "", "", 16000, 400, 14, gui::color::black, gui::color::white);
    g.sys_box = last_idx(); hide(g.sys_box);

    gui::button_color_text(130, 30, 0, 0, gui::color::green, "save & close", gui::color::white, []() {
        g.system_prompt = el(g.sys_box).edit_text;
        toggle_sys_editor(false);
    });
    g.sys_save_btn = last_idx(); hide(g.sys_save_btn);

    gui::button_color_text(130, 30, 0, 0, gui::color::teal, "reset default", gui::color::white, []() {
        g.system_prompt = app_state::default_sys_prompt;
        el(g.sys_box).edit_text  = g.system_prompt;
        el(g.sys_box).cursor_pos = (int)g.system_prompt.size();
    });
    g.sys_reset_btn = last_idx(); hide(g.sys_reset_btn);

    for (int s = 0; s < 4; ++s) {
        gui::textbox(100, 100, 0, 0, "", "", 4000, 200, 12, gui::color::black, gui::color::pink);
        g.err_box[s] = last_idx(); hide(last_idx());
        gui::button_color_text(90, 28, 0, 0, gui::color::red, "close", gui::color::white, [s]() {
            hide(g.err_box[s]); hide(g.err_close[s]);
        });
        g.err_close[s] = last_idx(); hide(last_idx());
    }
}

} // namespace ui