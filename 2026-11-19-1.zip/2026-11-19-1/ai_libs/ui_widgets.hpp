#pragma once
#include "../bilal_gui/gui.hpp"
#include "state.hpp"
#include "utils.hpp"
#include "storage.hpp"
#include "llm.hpp"
#include <algorithm>
#include <chrono>
#include <cstdio>

namespace ui {

inline int cancel_idx = -1;
inline int stats_idx  = -1;
inline std::string agent_info = "Agent: (none)";
inline std::chrono::steady_clock::time_point gen_start{};

inline gui::core::element& el(int idx) { return gui::core::ctx().elements[idx]; }
inline int last_idx() { return (int)gui::core::ctx().elements.size() - 1; }

inline void set_rect(int idx, int x, int y, int w, int h) {
    if (idx < 0) return;
    auto& e = el(idx);
    e.x = x; e.y = y; e.w = w; e.h = h;
}
inline void hide(int idx) { set_rect(idx, -10000, -10000, 200, 40); }

inline void set_box(int idx, const std::string& s, uint32_t fg, uint32_t bg, int cap_c, int cap_l) {
    if (idx < 0) return;
    std::string t = utils::cap_text(s, cap_c, cap_l);
    int lc = utils::line_count(t);
    auto& e = el(idx);
    e.edit_text   = t;
    e.maxchar     = std::max<int>(cap_c, (int)t.size() + 1024);
    e.maxlines    = std::max(cap_l, lc + 64);
    e.cursor_pos  = (int)t.size();
    e.scroll_line = (lc > 15) ? std::max(0, lc - 15) : 0;
    e.text_color  = fg;
    e.input_bg    = bg;
}

inline void set_ai(const std::string& s)   { set_box(g.ai_idx,   s, 0xFFFFFF, 0x000000, 200000, 4000); }
inline void set_user(const std::string& s) { set_box(g.user_idx, s, 0x000000, 0xFFFFFF, 100000, 2000); }

inline void update_stats(double avg_tps, double total_sec, int total_toks) {
    if (stats_idx < 0) return;
    char buf[512];
    std::snprintf(buf, sizeof(buf),
                  "%s\nAVG Tkns/s: %.2f\ntotal time: %.2fs\ntotal tokens: %d",
                  agent_info.c_str(), avg_tps, total_sec, total_toks);
    set_box(stats_idx, buf, 0xFFFFFF, 0x000000, 2000, 20);
    el(stats_idx).scroll_line = 0;
}

inline void show_error(const std::string& msg) {
    int slot = g.next_err++ % 4;
    int bi = g.err_box[slot], ci = g.err_close[slot];
    if (bi < 0) return;

    std::string t = utils::cap_text(msg, 4000, 200);
    auto& e = el(bi);
    e.edit_text = t;
    e.maxchar = std::max(1, (int)t.size());
    e.maxlines = std::max(1, utils::line_count(t));
    e.cursor_pos = e.scroll_line = 0;

    int W = gui::window_width(), H = gui::window_height();
    int w = W * 6 / 10, h = H * 3 / 10;
    int x = (W - w) / 2, y = (H - h) / 2 + slot * 20;
    set_rect(bi, x, y, w, h);
    set_rect(ci, x + w - 90, y - 32, 90, 28);
    el(ci).text_content = "close";
    el(ci).parent_menu  = -1;
    el(ci).visible      = true;
}

inline void refresh_menus() {
    for (int i = 0; i < g.chats_slots; ++i) {
        int fi = g.chats_scroll + i;
        el(g.chats_slot0 + i).text_content = (fi < (int)g.chat_files.size())
            ? storage::first_prompt_label(g.chat_dir + "/" + g.chat_files[fi]) : "";
    }

    std::vector<std::string> prompts;
    for (auto& m : g.history) if (m.role == "user") prompts.push_back(m.content);
    g.prompts_scroll = std::min(g.prompts_scroll, std::max(0, (int)prompts.size() - 1));

    for (int i = 0; i < g.prompts_slots; ++i) {
        int pi = g.prompts_scroll + i;
        if (pi < (int)prompts.size()) {
            std::string lbl = prompts[pi];
            std::replace(lbl.begin(), lbl.end(), '\n', ' ');
            el(g.prompts_slot0 + i).text_content = lbl.size() > 50 ? lbl.substr(0, 50) + "..." : lbl;
        } else {
            el(g.prompts_slot0 + i).text_content = "";
        }
    }
}

inline void layout() {
    int W = gui::window_width(), H = gui::window_height();
    if (W <= 0 || H <= 0) return;

    const int gap = 6, top_h = std::max(40, H / 14), bot_h = std::max(120, H / 7), item_h = std::max(32, top_h - gap);
    int chats_w = std::max(120, W / 9), prompts_w = std::max(160, W / 7);
    int right_x = gap + chats_w + gap + prompts_w + gap;
    int right_w = std::max(200, W - right_x - gap);
    int conv_y  = top_h + gap;
    int conv_h  = std::max(80, H - top_h - bot_h - 2 * gap);
    int ai_w    = (right_w - gap) * 55 / 100;

    set_rect(g.bg_idx, 0, 0, W, H);
    int bw = (W - 7 * gap) / 6;
    for (int i = 0; i < 6; ++i) set_rect(g.top_btn[i], gap + i * (bw + gap), gap / 2, bw, top_h - gap);

    auto place_menu = [&](int tog, int up, int dn, int slot0, int count, int x, int w) {
        int sb = std::max(20, item_h / 2), tw = std::max(40, w - 2 * gap - 2 * (sb + 3));
        set_rect(tog, x, conv_y, tw, item_h);
        set_rect(up,  x + tw + 3, conv_y, sb, item_h);
        set_rect(dn,  x + tw + sb + 6, conv_y, sb, item_h);
        int ly = conv_y + item_h + 2;
        int vis = std::max(0, (H - bot_h - gap - ly + 2) / (item_h + 2));
        for (int i = 0; i < count; ++i)
            (i < vis) ? set_rect(slot0 + i, x, ly + i * (item_h + 2), w - 2 * gap, item_h) : hide(slot0 + i);
    };
    place_menu(g.chats_menu,   g.chats_up,   g.chats_dn,   g.chats_slot0,   g.chats_slots,   gap, chats_w);
    place_menu(g.prompts_menu, g.prompts_up, g.prompts_dn, g.prompts_slot0, g.prompts_slots, gap + chats_w + gap, prompts_w);

    set_rect(g.ai_idx,   right_x, conv_y, ai_w, conv_h);
    set_rect(g.user_idx, right_x + ai_w + gap, conv_y, right_w - gap - ai_w, conv_h);

    int bot_y = H - bot_h + gap;
    int bot_inner_h = bot_h - 2 * gap;
    int send_w = std::max(100, W / 10);
    int in_w = std::max(160, (W - send_w - 4 * gap) / 2);
    int btn_x = gap + in_w + gap;
    int btn_h = (bot_inner_h - gap) / 2;
    int stats_x = btn_x + send_w + gap;
    int stats_w = std::max(160, W - stats_x - gap);

    set_rect(g.input_idx, gap, bot_y, in_w, bot_inner_h);
    set_rect(g.send_idx,  btn_x, bot_y, send_w, btn_h);
    set_rect(cancel_idx,  btn_x, bot_y + btn_h + gap, send_w, bot_inner_h - btn_h - gap);
    set_rect(stats_idx,   stats_x, bot_y, stats_w, bot_inner_h);

    if (g.sys_editor_open) {
        int sw = W * 65 / 100, sh = H * 45 / 100;
        int sx = (W - sw) / 2, sy = (H - sh) / 2;
        set_rect(g.sys_box,       sx, sy, sw, sh);
        set_rect(g.sys_save_btn,  sx + sw - 130, sy - 34, 130, 30);
        set_rect(g.sys_reset_btn, sx + sw - 270, sy - 34, 130, 30);
    } else {
        hide(g.sys_box);
        hide(g.sys_save_btn);
        hide(g.sys_reset_btn);
    }

    int ew = W * 6 / 10, eh = H * 3 / 10;
    for (int s = 0; s < 4; ++s) {
        if (g.err_box[s] >= 0 && el(g.err_box[s]).x >= 0) {
            int x = (W - ew) / 2, y = (H - eh) / 2 + s * 20;
            set_rect(g.err_box[s], x, y, ew, eh);
            set_rect(g.err_close[s], x + ew - 90, y - 32, 90, 28);
        }
    }
}

} // namespace ui