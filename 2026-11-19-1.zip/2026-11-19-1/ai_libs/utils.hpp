#pragma once
#include <cstdio>
#include <cstring>
#include <string>
#include <algorithm>
#include <chrono>

namespace utils {

using clk = std::chrono::steady_clock;

inline int64_t now_ms() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
        clk::now().time_since_epoch()).count();
}

inline int line_count(const std::string& s) {
    return 1 + (int)std::count(s.begin(), s.end(), '\n');
}

inline std::string cap_text(const std::string& s, int maxchars, int maxlines) {
    int end = std::min<int>((int)s.size(), maxchars);
    int lines = 1;
    for (int i = 0; i < end; ++i)
        if (s[i] == '\n' && ++lines > maxlines) { end = i; break; }
    return s.substr(0, end);
}

inline std::string sanitize_filename(const std::string& s, int maxlen = 50) {
    std::string out;
    for (char c : s) {
        if ((int)out.size() >= maxlen) break;
        out += std::strchr("/\\:*?\"<>|\n\r\t", c) ? '_' : c;
    }
    while (!out.empty() && out.front() == ' ') out.erase(out.begin());
    while (!out.empty() && out.back()  == ' ') out.pop_back();
    return out.empty() ? "chat" : out;
}

inline std::string run_picker(const char* cmd) {
    FILE* p = popen(cmd, "r");
    if (!p) return {};
    char buf[8192];
    std::string out;
    while (fgets(buf, sizeof(buf), p)) out += buf;
    if (pclose(p) != 0) return {};
    while (!out.empty() && (out.back() == '\n' || out.back() == '\r')) out.pop_back();
    return out;
}

inline std::string pick_file(const char* filter) {
    std::string cmd = "zenity --file-selection";
    if (filter && *filter) cmd += std::string(" --file-filter=\"") + filter + "\"";
    return run_picker((cmd + " 2>/dev/null").c_str());
}

inline std::string pick_dir() {
    return run_picker("zenity --file-selection --directory 2>/dev/null");
}

} // namespace utils