#pragma once
#include "llama.h"
#include <string>
#include <vector>
#include <cstdint>

struct chat_msg {
    std::string role;
    std::string content;
};

struct app_state {
    // llama.cpp
    llama_model*       model = nullptr;
    llama_context*     ctx   = nullptr;
    const llama_vocab* vocab = nullptr;
    llama_sampler*     smpl  = nullptr;
    llama_batch        batch = {};

    bool    generating   = false;
    int     n_past       = 0;
    int     n_ctx        = 0;
    int     n_batch      = 512;
    int     max_reply    = 0;
    int     n_threads    = 4;
    int     reply_tokens = 0;
    int64_t last_flush   = 0;
    std::string reply_buf;

    // system prompt
    static constexpr const char* default_sys_prompt =
        "You are a helpful, concise, and accurate AI assistant. "
        "Follow the user's instructions directly and provide clear, well-structured answers.";
    std::string system_prompt = default_sys_prompt;
    bool sys_editor_open = false;

    // conversation & files
    std::vector<chat_msg>    history;
    std::vector<std::string> chat_files;
    std::string chat_dir = "chats";
    std::string current_chat;
    size_t      saved_count = 0;

    // UI indices
    int bg_idx = -1;
    int top_btn[6] = {-1, -1, -1, -1, -1, -1};

    int chats_menu = -1, chats_up = -1, chats_dn = -1;
    int chats_slot0 = -1, chats_slots = 24, chats_scroll = 0;

    int prompts_menu = -1, prompts_up = -1, prompts_dn = -1;
    int prompts_slot0 = -1, prompts_slots = 24, prompts_scroll = 0;

    int ai_idx = -1, user_idx = -1, input_idx = -1, send_idx = -1;

    // system prompt editor overlay
    int sys_box = -1, sys_save_btn = -1, sys_reset_btn = -1;

    int err_box[4]   = {-1, -1, -1, -1};
    int err_close[4] = {-1, -1, -1, -1};
    int next_err = 0;

    int last_w = 0, last_h = 0;
};

inline app_state g;