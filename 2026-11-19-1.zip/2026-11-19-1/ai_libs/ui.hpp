#pragma once
#include "ui_actions.hpp"

namespace ui {

inline void tick_and_draw() {
    auto& c = gui::core::ctx();
    int xfd = ConnectionNumber(c.dpy);

    auto render_now = [&]() {
        gui::render::draw_scene(c.backbuf);
        XCopyArea(c.dpy, c.backbuf, c.win, c.gc, 0, 0, c.width, c.height, 0, 0);
        XFlush(c.dpy);
    };

    render_now();
    while (c.running) {
        timeval tv{0, 10000};
        fd_set fds; FD_ZERO(&fds); FD_SET(xfd, &fds);
        if (select(xfd + 1, &fds, nullptr, nullptr, g.generating ? &tv : nullptr) < 0) {
            if (errno == EINTR) continue;
            break;
        }

        bool dirty = false;
        while (XPending(c.dpy)) {
            XEvent ev; XNextEvent(c.dpy, &ev);
            if (gui::render::process_event(ev)) dirty = true;
        }

        if (int w = gui::window_width(), h = gui::window_height(); w != g.last_w || h != g.last_h) {
            g.last_w = w; g.last_h = h; layout(); dirty = true;
        }

        bool finished = false;
        std::string err;
        if (llm::step(finished, err)) {
            if (!err.empty()) show_error(err);
            set_ai(g.reply_buf.empty() && finished ? "(empty response)" : g.reply_buf);
            if (finished) {
                double secs = std::chrono::duration<double>(std::chrono::steady_clock::now() - gen_start).count();
                double tps  = (secs > 0.0) ? ((double)g.reply_tokens / secs) : 0.0;
                update_stats(tps, secs, g.reply_tokens);
                refresh_menus();
            }
            dirty = true;
        }

        if (dirty && c.running) render_now();
    }
}

inline void shutdown() {
    if (g.generating) llm::finish();
    llm::free_model();
    llama_backend_free();
    auto& c = gui::core::ctx();
    for (auto& kv : c.image_cache) if (kv.second) XDestroyImage(kv.second);
    for (auto& kv : c.font_cache)  if (kv.second) XFreeFont(c.dpy, kv.second);
    if (c.backbuf) XFreePixmap(c.dpy, c.backbuf);
    if (c.gc)      XFreeGC(c.dpy, c.gc);
    if (c.win)     XDestroyWindow(c.dpy, c.win);
    if (c.dpy)     XCloseDisplay(c.dpy);
}

} // namespace ui