#pragma once
#include "llm_core.hpp"
#include "llm_gen.hpp"