#pragma once
#include "state.hpp"
#include "utils.hpp"
#include "llama.h"

#include <algorithm>
#include <cctype>
#include <climits>
#include <clocale>
#include <cstdio>
#include <string>
#include <thread>
#include <vector>

namespace llm {

// File-local runtime state (keeps state.hpp unchanged)
inline llama_batch_ext*      batch_ext = nullptr;
inline std::vector<chat_msg> synced_history;
inline std::string           synced_system;
inline std::string           synced_prefix;
inline std::string           active_system;

// ---------------------------------------------------------------------------
// One-time backend initialization
// ---------------------------------------------------------------------------
inline void ensure_backend_init() {
    static bool initialized = false;
    if (initialized) return;

    std::setlocale(LC_NUMERIC, "C");
    llama_log_set([](enum ggml_log_level level, const char* text, void*) {
        if (level >= GGML_LOG_LEVEL_ERROR && text) {
            std::fprintf(stderr, "%s", text);
        }
    }, nullptr);

    llama_backend_init();
    initialized = true;
}

// ---------------------------------------------------------------------------
// Text & UTF-8 helpers
// ---------------------------------------------------------------------------
inline void rstrip(std::string& s) {
    while (!s.empty() && std::isspace((unsigned char)s.back())) s.pop_back();
}

inline void trim_utf8_tail(std::string& s) {
    if (s.empty()) return;
    size_t k = s.size();
    while (k > 0 && ((unsigned char)s[k - 1] & 0xC0) == 0x80) --k;
    if (k == 0) { s.clear(); return; }
    unsigned char lead = (unsigned char)s[k - 1];
    size_t need = (lead >= 0xF0) ? 4 : (lead >= 0xE0) ? 3 : (lead >= 0xC0) ? 2 : 1;
    if (s.size() - (k - 1) < need) s.resize(k - 1);
}

// ---------------------------------------------------------------------------
// Tokenization & detokenization (bounds-checked)
// ---------------------------------------------------------------------------
inline std::vector<llama_token> tokenize(const std::string& s, bool add_special) {
    if (!g.vocab || s.empty() || s.size() > (size_t)INT_MAX) return {};

    const int need = -llama_tokenize(
        g.vocab, s.c_str(), (int)s.size(), nullptr, 0, add_special, true);
    if (need <= 0) return {};

    std::vector<llama_token> toks((size_t)need);
    const int got = llama_tokenize(
        g.vocab, s.c_str(), (int)s.size(), toks.data(), need, add_special, true);
    if (got < 0) return {};

    toks.resize((size_t)got);
    return toks;
}

inline std::string token_to_piece(llama_token tok) {
    if (!g.vocab) return {};

    char buf[256];
    int n = llama_token_to_piece(g.vocab, tok, buf, (int)sizeof(buf), 0, false);
    if (n >= 0) return std::string(buf, (size_t)n);
    if (n < -65536) return {};

    std::string big((size_t)(-n), '\0');
    int m = llama_token_to_piece(g.vocab, tok, big.data(), (int)big.size(), 0, false);
    return (m >= 0) ? big.substr(0, (size_t)m) : std::string{};
}

// ---------------------------------------------------------------------------
// KV memory & lifecycle management
// ---------------------------------------------------------------------------
inline int kv_used() {
    if (!g.ctx) return 0;
    const llama_pos max_pos = llama_memory_seq_pos_max(llama_get_memory(g.ctx), 0);
    return (max_pos >= 0) ? (int)(max_pos + 1) : 0;
}

inline void reset_kv() {
    if (g.ctx) llama_memory_seq_rm(llama_get_memory(g.ctx), 0, -1, -1);
    synced_history.clear();
    synced_system.clear();
    synced_prefix.clear();
    g.n_past = 0;
}

inline void free_context() {
    if (g.smpl)    { llama_sampler_free(g.smpl);      g.smpl    = nullptr; }
    if (batch_ext) { llama_batch_ext_free(batch_ext); batch_ext = nullptr; }
    if (g.ctx)     { llama_free(g.ctx);               g.ctx     = nullptr; }
    if (g.batch.token || g.batch.embd) llama_batch_free(g.batch);
    g.batch  = {};
    g.vocab  = nullptr;
    g.n_past = 0;
    synced_history.clear();
    synced_system.clear();
    synced_prefix.clear();
}

inline bool make_context() {
    if (!g.model) return false;
    free_context();

    const int ctx_train = llama_model_n_ctx_train(g.model);
    const int model_ctx = (ctx_train > 0) ? ctx_train : 4096;
    g.n_ctx     = std::clamp(model_ctx, 512, 4096);
    g.n_batch   = std::min(512, g.n_ctx);
    g.max_reply = std::clamp(g.n_ctx / 2, 256, 2048);

    const int hw = (int)std::thread::hardware_concurrency();
    g.n_threads  = std::clamp(hw > 0 ? hw / 2 : 4, 1, 12);

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx           = (uint32_t)g.n_ctx;
    cp.n_batch         = (uint32_t)g.n_batch;
    cp.n_threads       = g.n_threads;
    cp.n_threads_batch = std::clamp(hw > 0 ? hw : 4, 1, 16);

    g.ctx = llama_init_from_model(g.model, cp);
    if (!g.ctx) return false;

    g.vocab = llama_model_get_vocab(g.model);
    if (!g.vocab) { free_context(); return false; }

    batch_ext = llama_batch_ext_init(g.ctx);
    if (!batch_ext) { free_context(); return false; }

    return true;
}

inline void free_model() {
    free_context();
    if (g.model) { llama_model_free(g.model); g.model = nullptr; }
    g.history.clear();
    g.reply_buf.clear();
    g.current_chat.clear();
    g.saved_count    = 0;
    g.prompts_scroll = 0;
}

inline bool load_model(const std::string& path, std::string& err) {
    if (path.empty()) { err = "empty model path"; return false; }
    ensure_backend_init();

    if (g.model) free_model();

    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;

    g.model = llama_model_load_from_file(path.c_str(), mp);
    if (!g.model) { err = "failed to load model: " + path; return false; }

    if (!make_context()) {
        err = "failed to create context: " + path;
        free_model();
        return false;
    }
    return true;
}

} // namespace llm