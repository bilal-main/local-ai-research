#!/usr/bin/env bash
# Portable builder: detects hardware, selects compiler/flags, verifies deps, builds, runs.
set -euo pipefail

# --- Resolve script directory (no hard-coded paths) -------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

LLAMA_DIR="./llama.cpp"
BUILD_DIR="$LLAMA_DIR/build"

# --- Dependency checks ------------------------------------------------------
die() { echo "ERROR: $*" >&2; exit 1; }

# --- CPU detection ------------------------------------------------------------
detect_cpu() {
    local arch=""
    local vendor=""
    local model=""
    local os_name=""

    # OS detection
    if [[ "$(uname -s)" == "Linux" ]]; then
        os_name="linux"
    elif [[ "$(uname -s)" == "Darwin" ]]; then
        os_name="macos"
    elif [[ "$(uname -s)" == "FreeBSD" ]]; then
        os_name="freebsd"
    else
        os_name="$(uname -s | tr '[:upper:]' '[:lower:]')"
    fi

    # Architecture detection — prefer machine over processor
    arch="$(uname -m)"
    case "$arch" in
        x86_64|amd64)
            arch="x86_64"
            ;;
        aarch64|arm64)
            arch="arm64"
            ;;
        armv7l|armv7a)
            arch="armv7"
            ;;
        i686|i386)
            arch="x86_32"
            ;;
        *)
            echo "WARN: Unknown arch '$arch' — using generic flags" >&2
            ;;
    esac

    # Vendor / family detection (Linux-specific, best-effort)
    if [[ "$os_name" == "linux" ]]; then
        if command -v lscpu &>/dev/null; then
            vendor="$(lscpu 2>/dev/null | grep -i "^Vendor" | head -1 | awk '{print $2}' || true)"
            model="$(lscpu 2>/dev/null | grep -i "^Model name" | head -1 | sed 's/.*Model name:\s*//' || true)"
        elif [[ -f /proc/cpuinfo ]]; then
            vendor="$(grep -m1 -i 'vendor_id' /proc/cpuinfo 2>/dev/null | awk -F: '{print $2}' | xargs || true)"
            model="$(grep -m1 -i 'model name' /proc/cpuinfo 2>/dev/null | awk -F: '{print $2}' | xargs || true)"
        fi

        # Normalize vendor strings
        case "${vendor,,}" in
            *genuineintel*|*intel*)
                vendor="intel"
                ;;
            *authenticamd*|*amd*)
                vendor="amd"
                ;;
            *apple*|*arm*)
                # On macOS via Rosetta, or Apple Silicon Linux (rare)
                vendor="apple"
                ;;
            *)
                vendor="unknown"
                ;;
        esac

        # If we detected arm64 but vendor looks x86, check for Rosetta
        if [[ "$arch" == "arm64" && "$vendor" == "unknown" && -f /usr/lib/oah/libosxtranslator.dylib ]]; then
            vendor="apple"
        fi
    elif [[ "$os_name" == "macos" ]]; then
        # macOS arm64 is always Apple Silicon
        if [[ "$arch" == "arm64" ]]; then
            vendor="apple"
        elif [[ "$arch" == "x86_64" ]]; then
            vendor="intel"
        fi
    fi

    echo "$os_name:$arch:$vendor"
}

# --- Compiler selection ------------------------------------------------------
select_compiler() {
    local arch="$1"
    local os_name="$2"
    local compiler=""
    local cxx=""

    case "$os_name:$arch" in
        linux:x86_64)
            # Prefer clang++ if available (better optimization profiles), fall back to g++
            if command -v clang++ &>/dev/null; then
                compiler="clang++"
                cxx="clang++"
            elif command -v g++ &>/dev/null; then
                compiler="g++"
                cxx="g++"
            else
                die "No C++ compiler found (need g++ or clang++)"
            fi
            ;;
        linux:arm64|linux:armv7)
            # ARM: typically g++ or aarch64-linux-gnu-g++ cross-compiler
            if command -v g++ &>/dev/null; then
                compiler="g++"
                cxx="g++"
            elif command -v clang++ &>/dev/null; then
                compiler="clang++"
                cxx="clang++"
            else
                die "No C++ compiler found (need g++ or clang++)"
            fi
            ;;
        macos:x86_64|macos:arm64)
            # macOS: clang++ is always available via Xcode toolchain
            if command -v clang++ &>/dev/null; then
                compiler="clang++"
                cxx="clang++"
            else
                die "No C++ compiler found (install Xcode command line tools: xcode-select --install)"
            fi
            ;;
        *)
            if command -v g++ &>/dev/null; then
                compiler="g++"
                cxx="g++"
            elif command -v clang++ &>/dev/null; then
                compiler="clang++"
                cxx="clang++"
            else
                die "No C++ compiler found (need g++ or clang++)"
            fi
            ;;
    esac

    echo "$cxx"
}

# --- Optimization flags per CPU family ----------------------------------------
select_flags() {
    local arch="$1"
    local vendor="$2"
    local os_name="$3"
    local flags="-std=c++17 -O2"

    case "$os_name:$vendor" in
        # Intel x86_64 — SSE4.2 + AVX2 is a safe baseline for >2013 CPUs
        linux:intel|macos:intel)
            flags="$flags -march=x86-64-v2 -msse4.2 -mavx2 -mfma -mf16c -mlzcnt"
            ;;
        linux:amd)
            # AMD — Zen architecture is very capable; use a broad but safe baseline
            flags="$flags -march=x86-64-v2 -msse4.2 -mavx2 -mfma -mf16c -mlzcnt"
            ;;
        linux:apple)
            # Apple Silicon — M-series chips support ARM NEON + SVE2
            flags="$flags -arch arm64 -mcpu=apple-a14 -ftree-vectorize"
            ;;
        linux:arm64)
            # Generic ARM64 — AArch64 with NEON
            flags="$flags -march=armv8-a+fp+simd -ftree-vectorize -ffast-math"
            ;;
        linux:armv7)
            # ARMv7 — Cortex-A with NEON
            flags="$flags -march=armv7-a+fp+neon -mfpu=neon-vfpv4 -ftree-vectorize -ffast-math"
            ;;
        linux:unknown|macos:*)
            # Unknown vendor — use safe baseline
            if [[ "$arch" == "x86_64" ]]; then
                flags="$flags -march=x86-64 -mtune=generic"
            elif [[ "$arch" == "arm64" ]]; then
                flags="$flags -march=armv8-a -ftree-vectorize"
            fi
            ;;
    esac

    echo "$flags"
}

# --- Main --------------------------------------------------------------------
echo ">> Detecting hardware..."
HARDWARE="$(detect_cpu)"
IFS=':' read -r OS_NAME ARCH VENDOR <<< "$HARDWARE"

echo "   OS: $OS_NAME | Arch: $ARCH | Vendor: $VENDOR"

echo ">> Selecting compiler..."
CXX="$(select_compiler "$ARCH" "$OS_NAME")"
echo "   Compiler: $CXX"

echo ">> Selecting optimization flags..."
EXTRA_FLAGS="$(select_flags "$ARCH" "$VENDOR" "$OS_NAME")"
echo "   Flags: $EXTRA_FLAGS"

# --- Dependency checks ------------------------------------------------------
command -v "$CXX" &>/dev/null || die "$CXX not found in PATH (install build-essential or Xcode CLT)"

# Header dirs
for d in ai_libs "$LLAMA_DIR/include" "$LLAMA_DIR/ggml/include"; do
  [ -d "$d" ] || die "Missing include dir: $d"
done

# Static libs produced by the llama.cpp cmake build
for f in \
  "$BUILD_DIR/src/libllama.a" \
  "$BUILD_DIR/ggml/src/libggml.a" \
  "$BUILD_DIR/ggml/src/libggml-cpu.a" \
  "$BUILD_DIR/ggml/src/libggml-base.a"
do
  [ -f "$f" ] || die "Missing $f — did you run the llama.cpp cmake build first?"
done

# System link deps (X11 etc.) — check dev libs exist where ld can see them
for lib in libX11 libxcb libXau libXdmcp; do
  if ! ldconfig -p 2>/dev/null | grep -q "$lib"; then
    echo "WARN: $lib not found via ldconfig; linking may fail" >&2
  fi
done

# --- Build ------------------------------------------------------------------
echo ">> Building fia_local_ai ..."
BIN=./ttt

# Capture stderr so we can drop the two known glibc/static-linker notices
# without hiding real errors.
err="$(mktemp)"
trap 'rm -f "$err"' EXIT

echo ">> Compiling with flags: $EXTRA_FLAGS"

if ! $CXX $EXTRA_FLAGS main.cpp -o "$BIN" \
    -Iai_libs -I"$LLAMA_DIR/include" -I"$LLAMA_DIR/ggml/include" \
    -Wl,--start-group \
      "$BUILD_DIR/src/libllama.a" \
      "$BUILD_DIR/ggml/src/libggml.a" \
      "$BUILD_DIR/ggml/src/libggml-cpu.a" \
      "$BUILD_DIR/ggml/src/libggml-base.a" \
    -Wl,--end-group \
    -lX11 -lxcb -lXau -lXdmcp -lm -ldl -lpthread -lgomp 2>"$err"; then
  cat "$err" >&2
  die "Compilation failed"
fi

# Filter out benign warnings about static linking
grep -vE "warning: Using '(dlopen|getaddrinfo)' in statically linked applications" "$err" >&2 || true

echo ">> Build OK: $SCRIPT_DIR/$BIN"

# --- Run (optional; comment out for CI) -------------------------------------
# exec "$BIN" "$@"
