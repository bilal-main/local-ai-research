#ifndef GUI_HPP
#define GUI_HPP

#include "gui_core.hpp"
#include "gui_image.hpp"
#include "gui_texture.hpp"
#include "gui_fonts.hpp"
#include "gui_media.hpp"
#include "gui_widgets.hpp"
#include "gui_menus.hpp"
#include "gui_render.hpp"

namespace gui {

    using core::init;
    using core::run;
    using core::window_width;
    using core::window_height;
    using core::display_width;
    using core::display_height;

    using widget::background_color;
    using widget::background_image;
    using widget::button_color;
    using widget::button_image;
    using widget::button_color_text;
    using widget::button_image_text;
    using widget::label;
    using widget::textbox;

    using vmenu_id = vmenu::id;
    using hmenu_id = hmenu::id;

} // namespace gui

namespace media = gui::media;

#endif