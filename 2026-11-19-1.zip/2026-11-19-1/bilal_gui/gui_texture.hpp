#ifndef GUI_TEXTURE_HPP
#define GUI_TEXTURE_HPP

#include "gui_core.hpp"
#include "gui_image.hpp"
#include <string>
#include <cstdio>
#include <unistd.h>

namespace gui { namespace texture {

inline XImage* get(const char* path) {
    if (!path || !*path) return nullptr;
    auto& cache = core::ctx().image_cache;
    auto it = cache.find(path);
    if (it != cache.end()) return it->second;

    std::string key(path);
    bool is_bmp = key.size() > 4 &&
                  (key.compare(key.size() - 4, 4, ".bmp") == 0 ||
                   key.compare(key.size() - 4, 4, ".BMP") == 0);

    XImage* img = nullptr;
    if (is_bmp) {
        img = image::load_bmp(core::ctx().dpy, core::ctx().screen, path);
    } else {
        char tmp[512];
        std::snprintf(tmp, sizeof(tmp), "/tmp/.gui_tex_%zx.bmp",
                      std::hash<std::string>{}(key));
        char cmd[1024];
        std::snprintf(cmd, sizeof(cmd),
                      "ffmpeg -y -loglevel quiet -i \"%s\" \"%s\" 2>/dev/null",
                      path, tmp);
        (void)!std::system(cmd);
        img = image::load_bmp(core::ctx().dpy, core::ctx().screen, tmp);
        unlink(tmp);
    }
    cache[key] = img;
    return img;
}

}}
#endif