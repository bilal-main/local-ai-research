#ifndef GUI_RENDER_HPP
#define GUI_RENDER_HPP

#include "gui_core.hpp"
#include "gui_texture.hpp"
#include "gui_fonts.hpp"
#include <X11/keysym.h>

namespace gui { namespace render {

constexpr int  PAD      = 5;
constexpr int  SB_WIDTH = 12;
constexpr int  LINE_GAP = 4;
constexpr long FLASH_MS = 130;
constexpr unsigned long SELECTION_COLOR = 0x3399FF;
constexpr unsigned long SCROLL_TRACK    = 0xDDDDDD;
constexpr unsigned long SCROLL_THUMB    = 0x666666;

inline int line_height(XFontStruct* f) { return f->ascent + f->descent + LINE_GAP; }
inline int char_w(XFontStruct* f)      { return f->max_bounds.width > 0 ? f->max_bounds.width : 8; }

inline int chars_per_line(const core::element& e, XFontStruct* f) {
    int inner = e.w - 2*PAD - SB_WIDTH;
    return std::max(1, inner / char_w(f));
}
inline int total_lines(const std::string& t) {
    int n = 1; for (char c : t) if (c == '\n') ++n; return n;
}
inline int visible_lines(const core::element& e, XFontStruct* f) {
    return std::max(1, (e.h - 2*PAD) / line_height(f));
}

// ---------------------------------------------------------------- soft wrap
struct wrapped_line { int start; int length; };

inline std::vector<wrapped_line> compute_wrap(const std::string& text, int cpl) {
    std::vector<wrapped_line> out;
    if (cpl < 1) cpl = 1;
    int n = (int)text.size();
    int i = 0;
    while (i <= n) {
        int nl = (int)text.find('\n', i);
        if (nl < 0) nl = n;
        int line_len = nl - i;
        if (line_len == 0) {
            out.push_back({i, 0});
        } else {
            int pos = i;
            while (pos < nl) {
                int remaining = nl - pos;
                if (remaining <= cpl) {
                    out.push_back({pos, remaining});
                    pos = nl;
                } else {
                    int space = -1;
                    int limit = pos + cpl;
                    for (int j = limit - 1; j > pos; --j) {
                        if (text[j] == ' ') { space = j; break; }
                    }
                    if (space > pos) {
                        out.push_back({pos, space - pos + 1});
                        pos = space + 1;
                    } else {
                        out.push_back({pos, cpl});
                        pos += cpl;
                    }
                }
            }
        }
        if (nl >= n) break;
        i = nl + 1;
    }
    if (out.empty()) out.push_back({0, 0});
    return out;
}

inline void index_to_display(const std::vector<wrapped_line>& lines,
                             int idx, int& dl, int& dc) {
    for (int i = 0; i < (int)lines.size(); ++i) {
        int start = lines[i].start;
        int end   = start + lines[i].length;
        if (idx >= start && idx < end) { dl = i; dc = idx - start; return; }
        if (idx == end) {
            if (i + 1 < (int)lines.size() && lines[i + 1].start == end) continue;
            dl = i; dc = lines[i].length; return;
        }
    }
    dl = (int)lines.size() - 1;
    dc = lines.back().length;
}

inline int display_to_index(const std::vector<wrapped_line>& lines, int dl, int dc) {
    if (lines.empty()) return 0;
    if (dl < 0) dl = 0;
    if (dl >= (int)lines.size()) dl = (int)lines.size() - 1;
    int start = lines[dl].start;
    int len   = lines[dl].length;
    if (dc < 0) dc = 0;
    if (dc > len) dc = len;
    return start + dc;
}

// ---------------------------------------------------------------- normalize (paste)
inline std::string normalize_textbox(const std::string& t, int maxchars, int maxlines) {
    std::string out;
    int ln = 1;
    for (char ch : t) {
        if ((int)out.size() >= maxchars) break;
        if (ch == '\n') {
            if (ln >= maxlines) break;
            ++ln;
        }
        out += ch;
    }
    return out;
}

// ---------------------------------------------------------------- selection helpers
inline bool has_selection(const core::element& e) {
    return e.sel_anchor >= 0 && e.sel_anchor != e.sel_end;
}
inline int sel_a(const core::element& e) { return std::min(e.sel_anchor, e.sel_end); }
inline int sel_b(const core::element& e) { return std::max(e.sel_anchor, e.sel_end); }

// ---------------------------------------------------------------- mouse → cursor
inline int textbox_cursor_from_xy(const core::element& e, XFontStruct* f,
                                   int mx, int my) {
    int lh  = line_height(f);
    int cpl = chars_per_line(e, f);
    auto lines = compute_wrap(e.edit_text, cpl);
    int row = (my - e.y - PAD) / lh;
    int dl  = std::max(0, std::min(row + e.scroll_line, (int)lines.size() - 1));
    int start = lines[dl].start;
    int len   = lines[dl].length;
    int target = mx - e.x - PAD;
    if (target <= 0) return start;
    int acc = 0;
    for (int i = 0; i < len; ++i) {
        int cw = XTextWidth(f, e.edit_text.c_str() + start + i, 1);
        if (target < acc + cw) return start + ((target - acc) < cw/2 ? i : i + 1);
        acc += cw;
    }
    return start + len;
}

// ---------------------------------------------------------------- border
inline void draw_border(Drawable dst, const core::element& e) {
    if (e.click_border_color == 0) return;
    auto& c = core::ctx();
    XSetForeground(c.dpy, c.gc, e.click_border_color);
    XSetLineAttributes(c.dpy, c.gc, 2, LineSolid, CapButt, JoinMiter);
    XDrawRectangle(c.dpy, dst, c.gc, e.x, e.y, e.w - 1, e.h - 1);
    XSetLineAttributes(c.dpy, c.gc, 0, LineSolid, CapButt, JoinMiter);
}

// ---------------------------------------------------------------- draw textbox
inline void draw_textbox(Drawable dst, core::element& e) {
    auto& c = core::ctx();
    XFontStruct* f = font::get(e.text_size);
    if (!f) f = XLoadQueryFont(c.dpy, "fixed");
    if (!f) f = XLoadQueryFont(c.dpy, "9x15");
    if (!f) return;

    int inner_h = e.h - 2 * PAD;
    if (f->ascent + f->descent > inner_h) {
        XFontStruct* fb = XLoadQueryFont(c.dpy, "fixed");
        if (fb) f = fb;
    }

    int lh  = line_height(f);
    int cpl = chars_per_line(e, f);
    int vis = visible_lines(e, f);

    if (e.cursor_pos > (int)e.edit_text.size()) e.cursor_pos = (int)e.edit_text.size();

    auto lines = compute_wrap(e.edit_text, cpl);
    int total = (int)lines.size();

    int cur_dl, cur_dc;
    index_to_display(lines, e.cursor_pos, cur_dl, cur_dc);

    if (total <= vis) e.scroll_line = 0;
    else {
        if (e.scroll_line < 0) e.scroll_line = 0;
        if (e.scroll_line > total - vis) e.scroll_line = total - vis;
    }

    bool focused = (c.focused_textbox >= 0 && &c.elements[c.focused_textbox] == &e);
    if (focused) {
        if (cur_dl < e.scroll_line) e.scroll_line = cur_dl;
        else if (cur_dl >= e.scroll_line + vis) e.scroll_line = cur_dl - vis + 1;
    }

    XSetForeground(c.dpy, c.gc, e.input_bg);
    XFillRectangle(c.dpy, dst, c.gc, e.x, e.y, e.w, e.h);
    XSetForeground(c.dpy, c.gc, color::gray);
    XDrawRectangle(c.dpy, dst, c.gc, e.x, e.y, e.w - 1, e.h - 1);

    int inner_w = e.w - 2*PAD - SB_WIDTH;
    XRectangle clip = { (short)(e.x + 1), (short)(e.y + 1),
                        (unsigned short)(inner_w + PAD + 1), (unsigned short)(e.h - 2) };
    XSetClipRectangles(c.dpy, c.gc, 0, 0, &clip, 1, Unsorted);

    XSetFont(c.dpy, c.gc, f->fid);

    bool sel = has_selection(e);
    int ss = sel ? sel_a(e) : 0, se = sel ? sel_b(e) : 0;

    for (int i = 0; i < vis; ++i) {
        int li = e.scroll_line + i;
        if (li >= total) break;
        int start = lines[li].start;
        int len   = lines[li].length;
        int ty    = e.y + PAD + i * lh;

        if (sel) {
            int os = std::max(start, ss);
            int oe = std::min(start + len, se);
            if (oe > os) {
                int xs = e.x + PAD + XTextWidth(f, e.edit_text.c_str() + start, os - start);
                int xe = e.x + PAD + XTextWidth(f, e.edit_text.c_str() + start, oe - start);
                XSetForeground(c.dpy, c.gc, SELECTION_COLOR);
                XFillRectangle(c.dpy, dst, c.gc, xs, ty, xe - xs, lh - 2);
            }
        }

        XSetForeground(c.dpy, c.gc, e.text_color);
        if (len > 0)
            XDrawString(c.dpy, dst, c.gc, e.x + PAD, ty + f->ascent,
                        e.edit_text.c_str() + start, len);
    }

    if (focused) {
        auto now_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
        if (c.drag_mode == 1 || (now_ms / 500) % 2 == 0) {
            if (cur_dl >= e.scroll_line && cur_dl < e.scroll_line + vis) {
                int line_start = lines[cur_dl].start;
                int cx = e.x + PAD + XTextWidth(f, e.edit_text.c_str() + line_start, cur_dc);
                int cy = e.y + PAD + (cur_dl - e.scroll_line) * lh;
                XSetForeground(c.dpy, c.gc, e.text_color);
                XDrawLine(c.dpy, dst, c.gc, cx, cy, cx, cy + lh - 2);
            }
        }
    }
    XSetClipMask(c.dpy, c.gc, None);

    int tx = e.x + e.w - SB_WIDTH - 2;
    int ty = e.y + PAD;
    int th = e.h - 2*PAD;
    XSetForeground(c.dpy, c.gc, SCROLL_TRACK);
    XFillRectangle(c.dpy, dst, c.gc, tx, ty, SB_WIDTH, th);
    if (total > vis) {
        int h_thumb = std::max(20, th * vis / total);
        int y_thumb = ty + (th - h_thumb) * e.scroll_line / (total - vis);
        XSetForeground(c.dpy, c.gc, SCROLL_THUMB);
        XFillRectangle(c.dpy, dst, c.gc, tx, y_thumb, SB_WIDTH, h_thumb);
    }
}

// ---------------------------------------------------------------- dispatcher
inline void draw_element(Drawable dst, core::element& e, bool flash) {
    auto& c = core::ctx();
    switch (e.type) {
        case core::element::bg_color: {
            XSetForeground(c.dpy, c.gc, e.color);
            XFillRectangle(c.dpy, dst, c.gc, e.x, e.y, e.w, e.h);
            break;
        }
        case core::element::btn_color: {
            unsigned long fill = e.color;
            if (flash) fill = (e.click_color != 0) ? e.click_color
                                                   : core::auto_click_color(e.color);
            XSetForeground(c.dpy, c.gc, fill);
            XFillRectangle(c.dpy, dst, c.gc, e.x, e.y, e.w, e.h);
            if (!e.text_content.empty())
                font::draw_centered(dst, e.x, e.y, e.w, e.h,
                                    e.text_size, e.text_content.c_str(),
                                    e.text_color);
            if (flash) draw_border(dst, e);
            break;
        }
        case core::element::bg_image: {
            XImage* img = texture::get(e.image_path.c_str());
            if (img) XPutImage(c.dpy, dst, c.gc, img, 0, 0,
                               e.x, e.y, img->width, img->height);
            break;
        }
        case core::element::btn_image: {
            XImage* img = texture::get(e.image_path.c_str());
            if (img) XPutImage(c.dpy, dst, c.gc, img, 0, 0,
                               e.x, e.y, img->width, img->height);
            if (flash) {
                XSetFunction(c.dpy, c.gc, GXxor);
                XSetForeground(c.dpy, c.gc, 0xFFFFFF);
                XFillRectangle(c.dpy, dst, c.gc, e.x, e.y, e.w, e.h);
                XSetFunction(c.dpy, c.gc, GXcopy);
            }
            if (!e.text_content.empty())
                font::draw_centered(dst, e.x, e.y, e.w, e.h,
                                    e.text_size, e.text_content.c_str(),
                                    e.text_color);
            if (flash) draw_border(dst, e);
            break;
        }
        case core::element::text:
            font::draw_at(dst, e.x, e.y, e.text_size,
                          e.text_content.c_str(), e.text_color);
            break;
        case core::element::textbox:
            draw_textbox(dst, e);
            break;
    }
}

inline void draw_scene(Drawable dst) {
    auto& c = core::ctx();
    XSetForeground(c.dpy, c.gc, BlackPixel(c.dpy, c.screen));
    XFillRectangle(c.dpy, dst, c.gc, 0, 0, c.width, c.height);

    auto now = std::chrono::steady_clock::now();
    for (auto& e : c.elements) {
        if (e.parent_menu >= 0 && !c.menus[e.parent_menu].visible) continue;
        bool flash = false;
        if (e.type == core::element::btn_color || e.type == core::element::btn_image) {
            auto el = std::chrono::duration_cast<std::chrono::milliseconds>(
                now - e.click_time).count();
            if (el < FLASH_MS) flash = true;
        }
        draw_element(dst, e, flash);
    }
}

// ---------------------------------------------------------------- keyboard
inline void handle_text_key(core::element& e, KeySym ks,
                            const char* buf, int len, unsigned int state) {
    auto& c = core::ctx();
    bool ctrl = (state & ControlMask) != 0;
    XFontStruct* f = font::get(e.text_size);
    if (!f) return;

    auto clamp_cursor = [&] {
        e.cursor_pos = std::max(0, std::min(e.cursor_pos, (int)e.edit_text.size()));
    };
    auto drop_sel = [&] { e.sel_anchor = -1; e.sel_end = -1; };
    auto cut_sel = [&]() -> bool {
        if (!has_selection(e)) return false;
        int s = sel_a(e), en = sel_b(e);
        e.edit_text.erase(s, en - s);
        e.cursor_pos = s;
        drop_sel();
        return true;
    };

    if (ctrl) {
        if (ks == XK_a || ks == XK_A) {
            e.sel_anchor = 0;
            e.sel_end    = (int)e.edit_text.size();
            e.cursor_pos = e.sel_end;
            return;
        }
        if (ks == XK_c || ks == XK_C) {
            if (has_selection(e))
                c.clipboard = e.edit_text.substr(sel_a(e), sel_b(e) - sel_a(e));
            return;
        }
        if (ks == XK_x || ks == XK_X) {
            if (has_selection(e)) {
                c.clipboard = e.edit_text.substr(sel_a(e), sel_b(e) - sel_a(e));
                cut_sel();
                core::write_text_file(e.output_path, e.edit_text);
            }
            return;
        }
        if (ks == XK_v || ks == XK_V) {
            if (c.clipboard.empty()) return;
            cut_sel();
            std::string paste = c.clipboard;
            if (e.maxlines == 1) {
                paste.erase(std::remove(paste.begin(), paste.end(), '\n'), paste.end());
                paste.erase(std::remove(paste.begin(), paste.end(), '\r'), paste.end());
            }
            e.edit_text.insert(e.cursor_pos, paste);
            e.cursor_pos += (int)paste.size();
            e.edit_text = normalize_textbox(e.edit_text, e.maxchar, e.maxlines);
            clamp_cursor();
            core::write_text_file(e.output_path, e.edit_text);
            return;
        }
    }

    switch (ks) {
        case XK_BackSpace:
            if (!cut_sel() && e.cursor_pos > 0) {
                e.edit_text.erase(e.cursor_pos - 1, 1);
                --e.cursor_pos;
            }
            core::write_text_file(e.output_path, e.edit_text);
            break;
        case XK_Delete:
            if (!cut_sel() && e.cursor_pos < (int)e.edit_text.size()) {
                e.edit_text.erase(e.cursor_pos, 1);
            }
            core::write_text_file(e.output_path, e.edit_text);
            break;
        case XK_Left:
            if (has_selection(e)) e.cursor_pos = sel_a(e);
            else if (e.cursor_pos > 0) --e.cursor_pos;
            drop_sel();
            break;
        case XK_Right:
            if (has_selection(e)) e.cursor_pos = sel_b(e);
            else if (e.cursor_pos < (int)e.edit_text.size()) ++e.cursor_pos;
            drop_sel();
            break;
        case XK_Home: {
            int cpl = chars_per_line(e, f);
            auto lines = compute_wrap(e.edit_text, cpl);
            int dl, dc;
            index_to_display(lines, e.cursor_pos, dl, dc);
            e.cursor_pos = display_to_index(lines, dl, 0);
            drop_sel();
            break;
        }
        case XK_End: {
            int cpl = chars_per_line(e, f);
            auto lines = compute_wrap(e.edit_text, cpl);
            int dl, dc;
            index_to_display(lines, e.cursor_pos, dl, dc);
            e.cursor_pos = display_to_index(lines, dl, lines[dl].length);
            drop_sel();
            break;
        }
        case XK_Return:
        case XK_KP_Enter:
            cut_sel();
            if ((int)e.edit_text.size() < e.maxchar &&
                total_lines(e.edit_text) < e.maxlines) {
                e.edit_text.insert(e.cursor_pos, 1, '\n');
                ++e.cursor_pos;
                core::write_text_file(e.output_path, e.edit_text);
            }
            break;
        case XK_Up: {
            int cpl = chars_per_line(e, f);
            auto lines = compute_wrap(e.edit_text, cpl);
            int dl, dc;
            index_to_display(lines, e.cursor_pos, dl, dc);
            if (dl > 0) e.cursor_pos = display_to_index(lines, dl - 1, dc);
            drop_sel();
            break;
        }
        case XK_Down: {
            int cpl = chars_per_line(e, f);
            auto lines = compute_wrap(e.edit_text, cpl);
            int dl, dc;
            index_to_display(lines, e.cursor_pos, dl, dc);
            if (dl + 1 < (int)lines.size()) e.cursor_pos = display_to_index(lines, dl + 1, dc);
            drop_sel();
            break;
        }
        default:
            if (len > 0) {
                unsigned char ch = (unsigned char)buf[0];
                if (ch >= 0x20 && ch < 0x7F) {
                    cut_sel();
                    if ((int)e.edit_text.size() < e.maxchar) {
                        e.edit_text.insert(e.cursor_pos, 1, (char)ch);
                        ++e.cursor_pos;
                        core::write_text_file(e.output_path, e.edit_text);
                    }
                }
            }
            break;
    }
    clamp_cursor();
}

// ---------------------------------------------------------------- events
inline bool process_event(XEvent& ev) {
    auto& c = core::ctx();

    if (ev.type == Expose) return ev.xexpose.count == 0;

    if (ev.type == ClientMessage) {
        Atom wm = XInternAtom(c.dpy, "WM_DELETE_WINDOW", False);
        if ((Atom)ev.xclient.data.l[0] == wm) c.running = false;
        return false;
    }

    if (ev.type == ConfigureNotify) {
        if (ev.xconfigure.width != c.width || ev.xconfigure.height != c.height) {
            c.width  = ev.xconfigure.width;
            c.height = ev.xconfigure.height;
            if (c.backbuf) XFreePixmap(c.dpy, c.backbuf);
            c.backbuf = XCreatePixmap(c.dpy, c.win, c.width, c.height,
                                      DefaultDepth(c.dpy, c.screen));
            return true;
        }
        return false;
    }

    if (ev.type == ButtonPress) {
        int mx = ev.xbutton.x, my = ev.xbutton.y;
        unsigned int btn = ev.xbutton.button;

        if (btn == 4 || btn == 5) {
            for (int i = (int)c.elements.size() - 1; i >= 0; --i) {
                auto& e = c.elements[i];
                if (e.type != core::element::textbox) continue;
                if (mx < e.x || mx >= e.x + e.w) continue;
                if (my < e.y || my >= e.y + e.h) continue;
                XFontStruct* f = font::get(e.text_size);
                if (!f) return false;
                int cpl = chars_per_line(e, f);
                auto lines = compute_wrap(e.edit_text, cpl);
                int total = (int)lines.size();
                int vis = visible_lines(e, f);
                if (total <= vis) return false;
                if (btn == 4) e.scroll_line = std::max(0, e.scroll_line - 1);
                else          e.scroll_line = std::min(total - vis, e.scroll_line + 1);
                return true;
            }
            return false;
        }

        if (btn != 1) return false;

        auto now = std::chrono::steady_clock::now();
        bool changed = false;
        int old_focus = c.focused_textbox;

        for (int i = (int)c.elements.size() - 1; i >= 0; --i) {
            auto& e = c.elements[i];
            if (e.parent_menu >= 0 && !c.menus[e.parent_menu].visible) continue;
            if (mx < e.x || mx >= e.x + e.w) continue;
            if (my < e.y || my >= e.y + e.h) continue;

            if (e.type == core::element::textbox) {
                XFontStruct* f = font::get(e.text_size);
                if (!f) { changed = true; break; }

                int cpl = chars_per_line(e, f);
                auto lines = compute_wrap(e.edit_text, cpl);
                int total = (int)lines.size();
                int vis = visible_lines(e, f);

                if (total > vis) {
                    int tx = e.x + e.w - SB_WIDTH - 2;
                    if (mx >= tx && mx < tx + SB_WIDTH) {
                        int track_y = e.y + PAD;
                        int track_h = e.h - 2*PAD;
                        int h_thumb = std::max(20, track_h * vis / total);
                        int y_thumb = track_y + (track_h - h_thumb) *
                                      e.scroll_line / (total - vis);
                        if (my >= y_thumb && my < y_thumb + h_thumb) {
                            c.dragging_element = i;
                            c.drag_mode = 2;
                            c.drag_thumb_offset = my - y_thumb;
                        } else if (my < y_thumb) {
                            e.scroll_line = std::max(0, e.scroll_line - vis);
                        } else {
                            e.scroll_line = std::min(total - vis,
                                                     e.scroll_line + vis);
                        }
                        if (old_focus != i && old_focus >= 0 &&
                            old_focus < (int)c.elements.size()) {
                            c.elements[old_focus].sel_anchor = -1;
                            c.elements[old_focus].sel_end = -1;
                        }
                        c.focused_textbox = i;
                        changed = true;
                        break;
                    }
                }

                if (old_focus != i && old_focus >= 0 &&
                    old_focus < (int)c.elements.size()) {
                    c.elements[old_focus].sel_anchor = -1;
                    c.elements[old_focus].sel_end = -1;
                }
                int pos = textbox_cursor_from_xy(e, f, mx, my);
                e.cursor_pos       = pos;
                e.sel_anchor       = pos;
                e.sel_end          = pos;
                c.focused_textbox  = i;
                c.dragging_element = i;
                c.drag_mode        = 1;
                changed = true;
                break;
            }

            if (e.type == core::element::btn_color ||
                e.type == core::element::btn_image) {
                e.click_time = now;
                c.anim_until = now + std::chrono::milliseconds(FLASH_MS);
                c.focused_textbox = -1;
                if (e.callback) e.callback();
                changed = true;
                break;
            }
        }
        if (!changed && old_focus >= 0) {
            if (old_focus < (int)c.elements.size()) {
                c.elements[old_focus].sel_anchor = -1;
                c.elements[old_focus].sel_end = -1;
            }
            c.focused_textbox = -1;
            changed = true;
        }
        return changed;
    }

    if (ev.type == ButtonRelease) {
        bool was_dragging = (c.drag_mode != 0);
        c.drag_mode        = 0;
        c.dragging_element = -1;
        return was_dragging;
    }

    if (ev.type == MotionNotify) {
        if (c.drag_mode == 0 || c.dragging_element < 0) return false;
        if (c.dragging_element >= (int)c.elements.size()) return false;
        auto& e = c.elements[c.dragging_element];
        XFontStruct* f = font::get(e.text_size);
        if (!f) return false;
        int mx = ev.xmotion.x, my = ev.xmotion.y;

        if (c.drag_mode == 1) {
            int pos = textbox_cursor_from_xy(e, f, mx, my);
            e.sel_end    = pos;
            e.cursor_pos = pos;
            return true;
        }
        if (c.drag_mode == 2) {
            int cpl = chars_per_line(e, f);
            auto lines = compute_wrap(e.edit_text, cpl);
            int total = (int)lines.size();
            int vis = visible_lines(e, f);
            if (total <= vis) return false;
            int track_y = e.y + PAD;
            int track_h = e.h - 2*PAD;
            int h_thumb = std::max(20, track_h * vis / total);
            int span    = track_h - h_thumb;
            if (span <= 0) return false;
            int rel  = my - c.drag_thumb_offset - track_y;
            int line = rel * (total - vis) / span;
            e.scroll_line = std::max(0, std::min(total - vis, line));
            return true;
        }
        return false;
    }

    if (ev.type == KeyPress) {
        if (c.focused_textbox < 0 ||
            c.focused_textbox >= (int)c.elements.size()) return false;
        char buf[8] = {0};
        KeySym ks = 0;
        int len = XLookupString(&ev.xkey, buf, sizeof(buf) - 1, &ks, nullptr);
        if (len == 0 && ks >= 0x20 && ks <= 0x7E) { buf[0] = (char)ks; len = 1; }
        handle_text_key(c.elements[c.focused_textbox], ks, buf, len, ev.xkey.state);
        return true;
    }

    return false;
}

}}
#endif