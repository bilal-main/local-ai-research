#ifndef GUI_MENUS_HPP
#define GUI_MENUS_HPP

#include "gui_core.hpp"

namespace gui { namespace vmenu {

struct id { int idx = -1; };

// ---------------------------------------------------------------- scroll
inline void scroll_set(id m, int y) {
    if (m.idx < 0) return;
    core::ctx().menus[m.idx].scroll = std::max(0, y);
}
inline int scroll_get(id m) {
    if (m.idx < 0) return 0;
    return core::ctx().menus[m.idx].scroll;
}
inline void scroll_by(id m, int d) { scroll_set(m, scroll_get(m) + d); }
inline void scroll_reset(id m) { if (m.idx >= 0) core::ctx().menus[m.idx].scroll = 0; }

// ---------------------------------------------------------------- toggle buttons
inline id create_color(int w, int h, int x, int y, unsigned long clr,
                       std::function<void()> extra = nullptr,
                       unsigned long click_color        = 0,
                       unsigned long click_border_color = 0) {
    auto& c = core::ctx();
    int idx = (int)c.menus.size(); c.menus.push_back({});
    core::element e; e.type = core::element::btn_color;
    e.x=x; e.y=y; e.w=w; e.h=h; e.color=clr;
    e.click_color        = click_color;
    e.click_border_color = click_border_color;
    e.callback = [idx, extra]() {
        core::ctx().menus[idx].visible = !core::ctx().menus[idx].visible;
        if (extra) extra();
    };
    c.elements.push_back(e);
    return {idx};
}
inline id create_text(int w, int h, int x, int y, const char* label,
                      unsigned long fg, unsigned long bg = 0x444444,
                      std::function<void()> extra = nullptr,
                      unsigned long click_color        = 0,
                      unsigned long click_border_color = 0) {
    auto& c = core::ctx();
    int idx = (int)c.menus.size(); c.menus.push_back({});
    core::element e; e.type = core::element::btn_color;
    e.x=x; e.y=y; e.w=w; e.h=h; e.color=bg;
    e.text_content = label ? label : "";
    e.text_size    = std::max(8, h/3);
    e.text_color   = fg;
    e.click_color        = click_color;
    e.click_border_color = click_border_color;
    e.callback = [idx, extra]() {
        core::ctx().menus[idx].visible = !core::ctx().menus[idx].visible;
        if (extra) extra();
    };
    c.elements.push_back(e);
    return {idx};
}
inline id create_image(int w, int h, int x, int y, const char* path,
                       std::function<void()> extra = nullptr,
                       unsigned long click_border_color = 0) {
    auto& c = core::ctx();
    int idx = (int)c.menus.size(); c.menus.push_back({});
    core::element e; e.type = core::element::btn_image;
    e.x=x; e.y=y; e.w=w; e.h=h; e.image_path = path ? path : "";
    e.click_border_color = click_border_color;
    e.callback = [idx, extra]() {
        core::ctx().menus[idx].visible = !core::ctx().menus[idx].visible;
        if (extra) extra();
    };
    c.elements.push_back(e);
    return {idx};
}

// ---------------------------------------------------------------- items
inline void button_color(id m, int w, int h, int x, int y, unsigned long clr,
                         std::function<void()> cb = nullptr,
                         unsigned long click_color        = 0,
                         unsigned long click_border_color = 0) {
    if (m.idx < 0) return;
    core::element e; e.type = core::element::btn_color;
    e.x=x; e.y=y; e.w=w; e.h=h; e.color=clr;
    e.callback=cb;
    e.click_color        = click_color;
    e.click_border_color = click_border_color;
    e.parent_menu        = m.idx;
    core::ctx().elements.push_back(e);
}
inline void button_color_text(id m, int w, int h, int x, int y,
                              unsigned long bg, const char* label, unsigned long fg,
                              std::function<void()> cb = nullptr,
                              unsigned long click_color        = 0,
                              unsigned long click_border_color = 0) {
    if (m.idx < 0) return;
    core::element e; e.type = core::element::btn_color;
    e.x=x; e.y=y; e.w=w; e.h=h; e.color=bg;
    e.text_content = label ? label : "";
    e.text_size    = std::max(8, h/3);
    e.text_color   = fg; e.callback = cb;
    e.click_color        = click_color;
    e.click_border_color = click_border_color;
    e.parent_menu        = m.idx;
    core::ctx().elements.push_back(e);
}
inline void button_image(id m, int w, int h, int x, int y, const char* path,
                         std::function<void()> cb = nullptr,
                         unsigned long click_border_color = 0) {
    if (m.idx < 0) return;
    core::element e; e.type = core::element::btn_image;
    e.x=x; e.y=y; e.w=w; e.h=h; e.image_path = path ? path : "";
    e.callback           = cb;
    e.click_border_color = click_border_color;
    e.parent_menu        = m.idx;
    core::ctx().elements.push_back(e);
}
inline void button_image_text(id m, int w, int h, int x, int y,
                              const char* path, const char* label, unsigned long fg,
                              std::function<void()> cb = nullptr,
                              unsigned long click_border_color = 0) {
    if (m.idx < 0) return;
    core::element e; e.type = core::element::btn_image;
    e.x=x; e.y=y; e.w=w; e.h=h; e.image_path = path ? path : "";
    e.text_content       = label ? label : "";
    e.text_size          = std::max(8, h/3);
    e.text_color         = fg;
    e.callback           = cb;
    e.click_border_color = click_border_color;
    e.parent_menu        = m.idx;
    core::ctx().elements.push_back(e);
}
inline void background_color(id m, int w, int h, int x, int y, unsigned long clr) {
    if (m.idx < 0) return;
    core::element e; e.type = core::element::bg_color;
    e.x=x; e.y=y; e.w=w; e.h=h; e.color=clr;
    e.parent_menu = m.idx;
    core::ctx().elements.push_back(e);
}
inline void background_image(id m, int w, int h, int x, int y, const char* path) {
    if (m.idx < 0) return;
    core::element e; e.type = core::element::bg_image;
    e.x=x; e.y=y; e.w=w; e.h=h; e.image_path = path ? path : "";
    e.parent_menu = m.idx;
    core::ctx().elements.push_back(e);
}
inline void label(id m, int x, int y, int size, const char* str, unsigned long clr) {
    if (m.idx < 0) return;
    core::element e; e.type = core::element::text;
    e.x=x; e.y=y; e.w=0; e.h=size;
    e.text_content = str ? str : "";
    e.text_size    = size;
    e.text_color   = clr;
    e.parent_menu  = m.idx;
    core::ctx().elements.push_back(e);
}

// ---------------------------------------------------------------- slot helper
// Creates one reusable slot inside the menu and returns its element index.
// Position and size are set to 0; layout() moves it into place with set_rect().
// The label starts empty; refresh_slots() (caller-side) fills it.
inline int slot(id m, const char* placeholder_label, unsigned long fg,
                unsigned long bg, std::function<void()> cb) {
    if (m.idx < 0) return -1;
    int idx = (int)core::ctx().elements.size();
    button_color_text(m, 0, 0, 0, 0, bg, placeholder_label, fg, cb);
    return idx;
}

}} // namespace gui::vmenu


namespace gui { namespace hmenu {

struct id { int idx = -1; };

inline void scroll_set(id m, int x) {
    if (m.idx < 0) return;
    core::ctx().menus[m.idx].scroll = std::max(0, x);
}
inline int scroll_get(id m) {
    if (m.idx < 0) return 0;
    return core::ctx().menus[m.idx].scroll;
}
inline void scroll_by(id m, int d) { scroll_set(m, scroll_get(m) + d); }
inline void scroll_reset(id m) { if (m.idx >= 0) core::ctx().menus[m.idx].scroll = 0; }

inline id create_color(int w, int h, int x, int y, unsigned long clr,
                       std::function<void()> extra = nullptr,
                       unsigned long click_color        = 0,
                       unsigned long click_border_color = 0) {
    auto& c = core::ctx();
    int idx = (int)c.menus.size(); c.menus.push_back({});
    c.menus[idx].cursor_x = x;
    c.menus[idx].item_y   = y + h + 6;
    core::element e; e.type = core::element::btn_color;
    e.x=x; e.y=y; e.w=w; e.h=h; e.color=clr;
    e.click_color        = click_color;
    e.click_border_color = click_border_color;
    e.callback = [idx, extra]() {
        core::ctx().menus[idx].visible = !core::ctx().menus[idx].visible;
        if (extra) extra();
    };
    c.elements.push_back(e);
    return {idx};
}
inline id create_text(int w, int h, int x, int y, const char* label,
                      unsigned long fg, unsigned long bg = 0x444444,
                      std::function<void()> extra = nullptr,
                      unsigned long click_color        = 0,
                      unsigned long click_border_color = 0) {
    auto& c = core::ctx();
    int idx = (int)c.menus.size(); c.menus.push_back({});
    c.menus[idx].cursor_x = x;
    c.menus[idx].item_y   = y + h + 6;
    core::element e; e.type = core::element::btn_color;
    e.x=x; e.y=y; e.w=w; e.h=h; e.color=bg;
    e.text_content = label ? label : "";
    e.text_size    = std::max(8, h/3);
    e.text_color   = fg;
    e.click_color        = click_color;
    e.click_border_color = click_border_color;
    e.callback = [idx, extra]() {
        core::ctx().menus[idx].visible = !core::ctx().menus[idx].visible;
        if (extra) extra();
    };
    c.elements.push_back(e);
    return {idx};
}
inline id create_image(int w, int h, int x, int y, const char* path,
                       std::function<void()> extra = nullptr,
                       unsigned long click_border_color = 0) {
    auto& c = core::ctx();
    int idx = (int)c.menus.size(); c.menus.push_back({});
    c.menus[idx].cursor_x = x;
    c.menus[idx].item_y   = y + h + 6;
    core::element e; e.type = core::element::btn_image;
    e.x=x; e.y=y; e.w=w; e.h=h; e.image_path = path ? path : "";
    e.click_border_color = click_border_color;
    e.callback = [idx, extra]() {
        core::ctx().menus[idx].visible = !core::ctx().menus[idx].visible;
        if (extra) extra();
    };
    c.elements.push_back(e);
    return {idx};
}

inline void button_color(id m, int w, int h, unsigned long clr,
                         std::function<void()> cb = nullptr,
                         unsigned long click_color        = 0,
                         unsigned long click_border_color = 0) {
    if (m.idx < 0) return;
    auto& ms = core::ctx().menus[m.idx];
    core::element e; e.type = core::element::btn_color;
    e.x=ms.cursor_x; e.y=ms.item_y; e.w=w; e.h=h; e.color=clr;
    e.callback=cb;
    e.click_color        = click_color;
    e.click_border_color = click_border_color;
    e.parent_menu        = m.idx;
    core::ctx().elements.push_back(e);
    ms.cursor_x += w + 6;
}
inline void button_color_text(id m, int w, int h,
                              unsigned long bg, const char* label, unsigned long fg,
                              std::function<void()> cb = nullptr,
                              unsigned long click_color        = 0,
                              unsigned long click_border_color = 0) {
    if (m.idx < 0) return;
    auto& ms = core::ctx().menus[m.idx];
    core::element e; e.type = core::element::btn_color;
    e.x=ms.cursor_x; e.y=ms.item_y; e.w=w; e.h=h; e.color=bg;
    e.text_content = label ? label : "";
    e.text_size    = std::max(8, h/3);
    e.text_color   = fg; e.callback = cb;
    e.click_color        = click_color;
    e.click_border_color = click_border_color;
    e.parent_menu        = m.idx;
    core::ctx().elements.push_back(e);
    ms.cursor_x += w + 6;
}
inline void button_image(id m, int w, int h, const char* path,
                         std::function<void()> cb = nullptr,
                         unsigned long click_border_color = 0) {
    if (m.idx < 0) return;
    auto& ms = core::ctx().menus[m.idx];
    core::element e; e.type = core::element::btn_image;
    e.x=ms.cursor_x; e.y=ms.item_y; e.w=w; e.h=h; e.image_path = path ? path : "";
    e.callback           = cb;
    e.click_border_color = click_border_color;
    e.parent_menu        = m.idx;
    core::ctx().elements.push_back(e);
    ms.cursor_x += w + 6;
}
inline void button_image_text(id m, int w, int h,
                              const char* path, const char* label, unsigned long fg,
                              std::function<void()> cb = nullptr,
                              unsigned long click_border_color = 0) {
    if (m.idx < 0) return;
    auto& ms = core::ctx().menus[m.idx];
    core::element e; e.type = core::element::btn_image;
    e.x=ms.cursor_x; e.y=ms.item_y; e.w=w; e.h=h; e.image_path = path ? path : "";
    e.text_content       = label ? label : "";
    e.text_size          = std::max(8, h/3);
    e.text_color         = fg;
    e.callback           = cb;
    e.click_border_color = click_border_color;
    e.parent_menu        = m.idx;
    core::ctx().elements.push_back(e);
    ms.cursor_x += w + 6;
}
inline int slot(id m, const char* placeholder_label, unsigned long fg,
                unsigned long bg, std::function<void()> cb) {
    if (m.idx < 0) return -1;
    int idx = (int)core::ctx().elements.size();
    button_color_text(m, 0, 0, bg, placeholder_label, fg, cb);
    return idx;
}

}} // namespace gui::hmenu
#endif