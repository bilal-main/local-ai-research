#ifndef GUI_IMAGE_HPP
#define GUI_IMAGE_HPP

#include "gui_core.hpp"

namespace gui { namespace image {

inline XImage* load_bmp(Display* dpy, int scr, const char* path) {
    FILE* f = fopen(path, "rb");
    if (!f) return nullptr;
    unsigned char hdr[54];
    if (fread(hdr, 1, 54, f) != 54) { fclose(f); return nullptr; }
    if (hdr[0] != 'B' || hdr[1] != 'M') { fclose(f); return nullptr; }
    uint32_t pixel_offset = *(uint32_t*)(hdr + 10);
    int32_t  width        = *(int32_t *)(hdr + 18);
    int32_t  height       = *(int32_t *)(hdr + 22);
    uint16_t bpp          = *(uint16_t*)(hdr + 28);
    uint32_t compression  = *(uint32_t*)(hdr + 30);
    if (compression != 0 || (bpp != 24 && bpp != 32) || width <= 0 || height == 0) {
        fclose(f); return nullptr;
    }
    bool top_down = height < 0; if (top_down) height = -height;
    const int row_bytes = ((width * bpp + 31) / 32) * 4;
    std::vector<unsigned char> data((size_t)height * row_bytes);
    if (fseek(f, pixel_offset, SEEK_SET) != 0 ||
        fread(data.data(), 1, data.size(), f) != data.size()) {
        fclose(f); return nullptr;
    }
    fclose(f);
    XImage* img = XCreateImage(dpy, DefaultVisual(dpy, scr),
                               DefaultDepth(dpy, scr), ZPixmap, 0,
                               (char*)std::malloc((size_t)width * height * 4),
                               width, height, 32, 0);
    if (!img) return nullptr;
    for (int y = 0; y < height; ++y) {
        int src_y = top_down ? y : (height - 1 - y);
        const unsigned char* row = &data[(size_t)src_y * row_bytes];
        for (int x = 0; x < width; ++x) {
            const unsigned char* p = &row[x * (bpp / 8)];
            XPutPixel(img, x, y, ((unsigned long)p[2] << 16) |
                                 ((unsigned long)p[1] <<  8) |
                                 ((unsigned long)p[0]));
        }
    }
    return img;
}

}}
#endif