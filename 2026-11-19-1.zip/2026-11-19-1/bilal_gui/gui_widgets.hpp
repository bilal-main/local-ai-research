#ifndef GUI_WIDGETS_HPP
#define GUI_WIDGETS_HPP

#include "gui_core.hpp"

namespace gui { namespace widget {

inline void background_color(int w, int h, int x, int y, unsigned long clr) {
    core::element e; e.type = core::element::bg_color;
    e.x=x; e.y=y; e.w=w; e.h=h; e.color=clr;
    core::ctx().elements.push_back(e);
}
inline void background_image(int w, int h, int x, int y, const char* path) {
    core::element e; e.type = core::element::bg_image;
    e.x=x; e.y=y; e.w=w; e.h=h; e.image_path = path ? path : "";
    core::ctx().elements.push_back(e);
}

inline void button_color(int w, int h, int x, int y, unsigned long clr,
                         std::function<void()> cb = nullptr,
                         unsigned long click_color        = 0,
                         unsigned long click_border_color = 0) {
    core::element e; e.type = core::element::btn_color;
    e.x=x; e.y=y; e.w=w; e.h=h; e.color=clr;
    e.callback=cb;
    e.click_color        = click_color;
    e.click_border_color = click_border_color;
    core::ctx().elements.push_back(e);
}
inline void button_image(int w, int h, int x, int y, const char* path,
                         std::function<void()> cb = nullptr,
                         unsigned long click_border_color = 0) {
    core::element e; e.type = core::element::btn_image;
    e.x=x; e.y=y; e.w=w; e.h=h; e.image_path = path ? path : "";
    e.callback=cb;
    e.click_border_color = click_border_color;
    core::ctx().elements.push_back(e);
}
inline void button_color_text(int w, int h, int x, int y,
                              unsigned long bg, const char* label, unsigned long fg,
                              std::function<void()> cb = nullptr,
                              unsigned long click_color        = 0,
                              unsigned long click_border_color = 0) {
    core::element e; e.type = core::element::btn_color;
    e.x=x; e.y=y; e.w=w; e.h=h; e.color=bg;
    e.text_content = label ? label : "";
    e.text_size    = std::max(8, h/3);
    e.text_color   = fg;
    e.callback     = cb;
    e.click_color        = click_color;
    e.click_border_color = click_border_color;
    core::ctx().elements.push_back(e);
}
inline void button_image_text(int w, int h, int x, int y,
                              const char* path, const char* label, unsigned long fg,
                              std::function<void()> cb = nullptr,
                              unsigned long click_border_color = 0) {
    core::element e; e.type = core::element::btn_image;
    e.x=x; e.y=y; e.w=w; e.h=h; e.image_path = path ? path : "";
    e.text_content = label ? label : "";
    e.text_size    = std::max(8, h/3);
    e.text_color   = fg;
    e.callback     = cb;
    e.click_border_color = click_border_color;
    core::ctx().elements.push_back(e);
}

inline void label(int x, int y, int size, const char* str,
                  unsigned long clr = color::white) {
    core::element e; e.type = core::element::text;
    e.x=x; e.y=y; e.w=0; e.h=size;
    e.text_content = str ? str : "";
    e.text_size    = size;
    e.text_color   = clr;
    core::ctx().elements.push_back(e);
}

inline void textbox(int w, int h, int x, int y,
                       const char* initial, const char* output_path,
                       int maxchars, int maxlines,
                       int textsize            = 16,
                       unsigned long textcolor = 0x000000,
                       unsigned long bgcolor   = 0xFFFFFF) {
    core::element e; e.type = core::element::textbox;
    e.x=x; e.y=y; e.w=w; e.h=h;
    e.edit_text = initial ? initial : "";
    if ((int)e.edit_text.size() > maxchars) e.edit_text.resize(maxchars);
    e.cursor_pos  = (int)e.edit_text.size();
    e.output_path = output_path ? output_path : "";
    e.maxchar     = std::max(1, maxchars);
    e.maxlines    = std::max(1, maxlines);
    e.text_size   = std::max(8, textsize);
    e.text_color  = textcolor;
    e.input_bg    = bgcolor;
    core::ctx().elements.push_back(e);
}

}}
#endif