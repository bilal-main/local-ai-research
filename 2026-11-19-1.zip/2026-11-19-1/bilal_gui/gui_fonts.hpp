#ifndef GUI_FONTS_HPP
#define GUI_FONTS_HPP

#include "gui_core.hpp"

namespace gui { namespace font {

inline XFontStruct* get(int size) {
    auto& c = core::ctx();
    auto& cache = c.font_cache;
    auto it = cache.find(size);
    if (it != cache.end()) return it->second;
    char pattern[128];
    std::snprintf(pattern, sizeof(pattern),
                  "-*-*-*-*-*-*-%d-*-*-*-*-*-*-*", size);
    int n = 0;
    char** names = XListFonts(c.dpy, pattern, 1, &n);
    XFontStruct* f = nullptr;
    if (n > 0 && names) { f = XLoadQueryFont(c.dpy, names[0]);
                          XFreeFontNames(names); }
    if (!f) f = XLoadQueryFont(c.dpy, "fixed");
    if (!f) f = XLoadQueryFont(c.dpy, "9x15");
    cache[size] = f;
    return f;
}

inline void draw_at(Drawable dst, int x, int y, int size,
                    const char* str, unsigned long clr) {
    if (!str || !*str) return;
    auto& c = core::ctx();
    XFontStruct* f = get(size);
    if (!f) return;
    XSetFont(c.dpy, c.gc, f->fid);
    XSetForeground(c.dpy, c.gc, clr);
    XDrawString(c.dpy, dst, c.gc, x, y + f->ascent,
                str, (int)std::strlen(str));
}

inline void draw_centered(Drawable dst, int bx, int by, int bw, int bh,
                          int size, const char* str, unsigned long clr) {
    if (!str || !*str) return;
    auto& c = core::ctx();
    XFontStruct* f = get(size);
    if (!f) return;
    int len = (int)std::strlen(str);
    int tw  = XTextWidth(f, str, len);
    int th  = f->ascent + f->descent;
    XSetFont(c.dpy, c.gc, f->fid);
    XSetForeground(c.dpy, c.gc, clr);
    XDrawString(c.dpy, dst, c.gc,
                bx + (bw - tw) / 2, by + (bh - th) / 2 + f->ascent,
                str, len);
}

}}
#endif