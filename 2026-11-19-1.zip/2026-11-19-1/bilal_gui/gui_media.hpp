#ifndef GUI_MEDIA_HPP
#define GUI_MEDIA_HPP

#include <vector>
#include <string>
#include <algorithm>
#include <csignal>
#include <cerrno>
#include <climits>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

namespace gui { namespace media {

struct state_data {
    std::vector<pid_t> once_sounds, once_videos;
    pid_t loop_sound = 0, loop_video = 0;
};
inline state_data& state() { static state_data s; return s; }

inline bool is_alive(pid_t p) {
    if (p <= 0) return false;
    int status;
    return waitpid(p, &status, WNOHANG) == 0;
}
inline void reap(std::vector<pid_t>& v) {
    v.erase(std::remove_if(v.begin(), v.end(),
                          [](pid_t p){ return !is_alive(p); }), v.end());
}

inline int clamp_volume(int v) { return std::max(1, std::min(100, v)); }

inline void redirect_std_fds() {
    int dn = open("/dev/null", O_WRONLY);
    if (dn >= 0) {
        dup2(dn, STDOUT_FILENO);
        dup2(dn, STDERR_FILENO);
        if (dn > 2) close(dn);
    }
    for (int fd = 3; fd < 256; ++fd) close(fd);
}

// One-shot process: fork + exec, dies when the media is done.
inline pid_t spawn(const char* exe, std::vector<std::string> args) {
    std::vector<char*> argv;
    std::string exe_s = exe;
    argv.push_back(exe_s.data());
    for (auto& a : args) argv.push_back(a.data());
    argv.push_back(nullptr);

    pid_t p = fork();
    if (p == 0) {
        redirect_std_fds();
        execvp(exe, argv.data());
        _exit(127);
    }
    return p;
}

// Looping wrapper: forks a supervisor process in its own process group.
// The supervisor plays `exe args` sequentially:
//   - waits for each child to finish
//   - sleeps `delay_ms` between plays
//   - repeats `reps` times, or forever if reps < 0
//
// Killing the wrapper with  kill(-p, SIGTERM)  kills the supervisor AND
// whatever ffplay child it currently has running. Nothing survives.
inline pid_t spawn_loop(const char* exe, std::vector<std::string> args,
                        int reps, int delay_ms) {
    if (reps == 0) return 0;

    std::string exe_s = exe;
    std::vector<char*> argv;
    argv.push_back(exe_s.data());
    for (auto& a : args) argv.push_back(a.data());
    argv.push_back(nullptr);

    pid_t p = fork();
    if (p == 0) {
        setpgid(0, 0);                 // own process group
        redirect_std_fds();
        const int iterations = (reps < 0) ? INT_MAX : reps;
        for (int i = 0; i < iterations; ++i) {
            pid_t inner = fork();
            if (inner == 0) {
                execvp(exe, argv.data());
                _exit(127);
            }
            if (inner < 0) break;
            int status;
            while (waitpid(inner, &status, 0) < 0 && errno == EINTR) {}
            if (i + 1 < iterations && delay_ms > 0) {
                usleep((useconds_t)delay_ms * 1000);
            }
        }
        _exit(0);
    }
    if (p > 0) setpgid(p, p);          // register the group early in the parent
    return p;
}

// Stop a loop by killing the entire process group, then reaping the wrapper.
inline void stop_loop(pid_t& p) {
    if (p <= 0) return;
    kill(-p, SIGTERM);
    waitpid(p, nullptr, 0);
    p = 0;
}

inline void kill_all() {
    auto& s = state();
    for (auto p : s.once_sounds) if (p > 0) kill(p, SIGTERM);
    for (auto p : s.once_videos) if (p > 0) kill(p, SIGTERM);
    stop_loop(s.loop_sound);
    stop_loop(s.loop_video);
    s.once_sounds.clear();
    s.once_videos.clear();
}

inline int _atexit_registered = (std::atexit(kill_all), 0);

// ---- one-shot ----

inline void playsoundonce(const char* path, int volume = 100) {
    if (!path || !*path) return;
    auto& s = state();
    reap(s.once_sounds);
    if ((int)s.once_sounds.size() >= 3) return;
    std::string vol = std::to_string(clamp_volume(volume));
    pid_t p = spawn("ffplay", {"-nodisp", "-autoexit", "-loglevel", "quiet",
                               "-volume", vol, std::string(path)});
    if (p > 0) s.once_sounds.push_back(p);
}

inline void playvideoonce(int w, int h, int x, int y,
                          const char* path, int volume = 100) {
    if (!path || !*path) return;
    auto& s = state();
    reap(s.once_videos);
    if ((int)s.once_videos.size() >= 3) return;
    std::string vol = std::to_string(clamp_volume(volume));
    pid_t p = spawn("ffplay", {"-autoexit", "-loglevel", "quiet", "-volume", vol,
                               "-x", std::to_string(w), "-y", std::to_string(h),
                               "-left", std::to_string(x), "-top", std::to_string(y),
                               std::string(path)});
    if (p > 0) s.once_videos.push_back(p);
}

// ---- sequential loop with a gap between plays ----
//
//   reps = -1  → loop forever
//   reps =  0  → do nothing (no-op)
//   reps =  N  → play exactly N times
//
//   delay_ms   → silence between plays (0 = back-to-back, still sequential)
//
// Calling loopsound() while another loop is active stops the old one first.

inline void loopsound(const char* path, int volume = 100,
                      int reps = -1, int delay_ms = 200) {
    if (!path || !*path || reps == 0) return;
    auto& s = state();
    stop_loop(s.loop_sound);
    std::string vol = std::to_string(clamp_volume(volume));
    pid_t p = spawn_loop("ffplay",
                         {"-nodisp", "-autoexit", "-loglevel", "quiet",
                          "-volume", vol, std::string(path)},
                         reps, delay_ms);
    if (p > 0) s.loop_sound = p;
}

inline void loopvideo(int w, int h, int x, int y,
                      const char* path, int volume = 100,
                      int reps = -1, int delay_ms = 200) {
    if (!path || !*path || reps == 0) return;
    auto& s = state();
    stop_loop(s.loop_video);
    std::string vol = std::to_string(clamp_volume(volume));
    pid_t p = spawn_loop("ffplay",
                         {"-autoexit", "-loglevel", "quiet", "-volume", vol,
                          "-x", std::to_string(w), "-y", std::to_string(h),
                          "-left", std::to_string(x), "-top", std::to_string(y),
                          std::string(path)},
                         reps, delay_ms);
    if (p > 0) s.loop_video = p;
}

}}
#endif