#ifndef GUI_CORE_HPP
#define GUI_CORE_HPP

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <sys/select.h>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <climits>
#include <string>
#include <vector>
#include <functional>
#include <chrono>
#include <algorithm>
#include <unordered_map>
#include <csignal>

namespace gui { namespace color {
    constexpr unsigned long black   = 0x000000;
    constexpr unsigned long white   = 0xFFFFFF;
    constexpr unsigned long red     = 0xFF0000;
    constexpr unsigned long green   = 0x00AA00;
    constexpr unsigned long blue    = 0x0000FF;
    constexpr unsigned long yellow  = 0xFFFF00;
    constexpr unsigned long cyan    = 0x00FFFF;
    constexpr unsigned long magenta = 0xFF00FF;
    constexpr unsigned long gray    = 0x808080;
    constexpr unsigned long orange  = 0xFFA500;
    constexpr unsigned long purple  = 0x800080;
    constexpr unsigned long brown   = 0xA52A2A;
    constexpr unsigned long pink    = 0xFFC0CB;
    constexpr unsigned long lime    = 0x00FF00;
    constexpr unsigned long navy    = 0x000080;
    constexpr unsigned long teal    = 0x008080;
} }

namespace gui { namespace render {
    void draw_scene(Drawable dst);
    bool process_event(XEvent& ev);
} }

namespace gui { namespace core {

struct menu_state {
    bool visible  = false;
    int  cursor_x = 0;
    int  item_y   = 0;
    int scroll =0;
};

struct element {
    enum kind {
        bg_color, bg_image,
        btn_color, btn_image,
        text, textbox
    } type = bg_color;

    int x = 0, y = 0, w = 0, h = 0;
    unsigned long color = 0;
    std::string   image_path;
    std::function<void()> callback;
    int parent_menu = -1;
    bool visible;

    std::string   text_content;
    int           text_size  = 0;
    unsigned long text_color = 0xFFFFFF;

    unsigned long click_color        = 0;
    unsigned long click_border_color = 0;
    std::chrono::steady_clock::time_point click_time{};

    std::string   edit_text;
    int           cursor_pos  = 0;
    std::string   output_path;
    int           maxchar     = INT_MAX;
    int           maxlines    = INT_MAX;
    unsigned long input_bg    = 0xFFFFFF;
    int           sel_anchor  = -1;
    int           sel_end     = -1;
    int           scroll_line = 0;
};

struct context {
    Display* dpy     = nullptr;
    Window   win     = 0;
    GC       gc      = nullptr;
    Pixmap   backbuf = 0;
    int      screen  = 0;
    int      width   = 0, height = 0;
    int      disp_w  = 0, disp_h = 0;
    bool     running = true;
    int      focused_textbox = -1;
    std::string clipboard;
    int dragging_element  = -1;
    int drag_mode         = 0;
    int drag_thumb_offset = 0;
    std::chrono::steady_clock::time_point anim_until{};

    std::vector<element>    elements;
    std::vector<menu_state> menus;
    std::unordered_map<std::string, XImage*>      image_cache;
    std::unordered_map<int,         XFontStruct*> font_cache;
};

inline context& ctx() { static context c; return c; }

inline volatile std::sig_atomic_t& exit_flag() {
    static volatile std::sig_atomic_t f = 0;
    return f;
}
inline void signal_handler(int) { exit_flag() = 1; }

inline unsigned long auto_click_color(unsigned long base) {
    unsigned long r = std::min<unsigned long>(255, ((base >> 16) & 0xFF) + 70);
    unsigned long g = std::min<unsigned long>(255, ((base >>  8) & 0xFF) + 70);
    unsigned long b = std::min<unsigned long>(255, ((base      ) & 0xFF) + 70);
    return (r << 16) | (g << 8) | b;
}

inline void write_text_file(const std::string& path, const std::string& text) {
    if (path.empty()) return;
    FILE* f = fopen(path.c_str(), "wb");
    if (f) { fwrite(text.data(), 1, text.size(), f); fclose(f); }
}

inline bool init(int w, int h, const char* title) {
    context& c = ctx();
    c.dpy = XOpenDisplay(nullptr);
    if (!c.dpy) return false;
    c.screen = DefaultScreen(c.dpy);
    c.disp_w = DisplayWidth(c.dpy, c.screen);
    c.disp_h = DisplayHeight(c.dpy, c.screen);
    c.width = w; c.height = h;

    c.win = XCreateSimpleWindow(c.dpy, RootWindow(c.dpy, c.screen),
                                0, 0, w, h, 1,
                                BlackPixel(c.dpy, c.screen),
                                WhitePixel(c.dpy, c.screen));
    XStoreName(c.dpy, c.win, title);
    XSelectInput(c.dpy, c.win,
                 ExposureMask | ButtonPressMask | ButtonReleaseMask |
                 ButtonMotionMask | KeyPressMask | StructureNotifyMask);
    XMapWindow(c.dpy, c.win);

    Atom wm_delete = XInternAtom(c.dpy, "WM_DELETE_WINDOW", False);
    XSetWMProtocols(c.dpy, c.win, &wm_delete, 1);

    c.gc = XCreateGC(c.dpy, c.win, 0, nullptr);
    c.backbuf = XCreatePixmap(c.dpy, c.win, w, h,
                              DefaultDepth(c.dpy, c.screen));

    std::signal(SIGINT,  signal_handler);
    std::signal(SIGTERM, signal_handler);
    return true;
}

inline int window_width()   { return ctx().width; }
inline int window_height()  { return ctx().height; }
inline int display_width()  { return ctx().disp_w; }
inline int display_height() { return ctx().disp_h; }

inline void run() {
    context& c = ctx();
    int xfd = ConnectionNumber(c.dpy);

    render::draw_scene(c.backbuf);
    XCopyArea(c.dpy, c.backbuf, c.win, c.gc, 0, 0, c.width, c.height, 0, 0);
    XFlush(c.dpy);

    while (c.running && !exit_flag()) {
        auto now = std::chrono::steady_clock::now();
        struct timeval tv;
        struct timeval* tvp = nullptr;

        if (now < c.anim_until) {
            auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                c.anim_until - now).count() + 1;
            tv.tv_sec  = 0;
            tv.tv_usec = (suseconds_t)(ms * 1000);
            tvp = &tv;
        } else if (c.focused_textbox >= 0) {
            tv.tv_sec  = 0;
            tv.tv_usec = 500000;
            tvp = &tv;
        }

        fd_set fds;
        FD_ZERO(&fds);
        FD_SET(xfd, &fds);

        int rc = select(xfd + 1, &fds, nullptr, nullptr, tvp);
        if (rc < 0) {
            if (errno == EINTR) continue;
            break;
        }

        bool need_draw = (rc == 0);

        while (XPending(c.dpy)) {
            XEvent ev;
            XNextEvent(c.dpy, &ev);
            if (render::process_event(ev)) need_draw = true;
        }

        if (need_draw && c.running) {
            render::draw_scene(c.backbuf);
            XCopyArea(c.dpy, c.backbuf, c.win, c.gc,
                      0, 0, c.width, c.height, 0, 0);
            XFlush(c.dpy);
        }
    }

    for (auto& kv : c.image_cache) if (kv.second) XDestroyImage(kv.second);
    for (auto& kv : c.font_cache)  if (kv.second) XFreeFont(c.dpy, kv.second);
    if (c.backbuf) XFreePixmap(c.dpy, c.backbuf);
    if (c.gc)      XFreeGC(c.dpy, c.gc);
    if (c.win)     XDestroyWindow(c.dpy, c.win);
    if (c.dpy)     XCloseDisplay(c.dpy);
}

}}
#endif