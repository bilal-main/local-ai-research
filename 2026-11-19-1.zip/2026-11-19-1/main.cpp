#include "ai_libs/ui.hpp"

int main() {
    if (!gui::init(1200, 800, "local chat")) return 1;
    llama_backend_init();

    ui::build_scene();
    storage::scan_dir();
    ui::refresh_menus();
    ui::layout();
    g.last_w = gui::window_width();
    g.last_h = gui::window_height();

    ui::tick_and_draw();
    ui::shutdown();
    return 0;
}

/* USE THE FOLLOWING COMMAND TO BUILD THE EXECUTABLE
keep the structure of
main.cpp
buildAI.sh //must be in the same directory
    ai_libs
        .hpp//several .hpp files
    bilal_gui
        .hpp//several .hpp files
g++ -std=c++17 -O2 -static main.cpp -o llama_gui -Iai_libs -I./llama.cpp/include -I./llama.cpp/ggml/include -Wl,--start-group ./llama.cpp/build/src/libllama.a ./llama.cpp/build/ggml/src/libggml.a ./llama.cpp/build/ggml/src/libggml-cpu.a ./llama.cpp/build/ggml/src/libggml-base.a -Wl,--end-group -lX11 -lxcb -lXau -lXdmcp -lm -ldl -lpthread -lgomp 
*/